<?php
$page_title = "Admin Boshqaruv Paneli";
include 'includes/_admin_header.php'; 

$pending_tickets_query = mysqli_query($conn, "SELECT COUNT(*) as count FROM ticket_applications WHERE status = 'kutilmoqda'");
$pending_tickets_count = ($pending_tickets_query) ? mysqli_fetch_assoc($pending_tickets_query)['count'] : 0;

$pending_training_apps_query = mysqli_query($conn, "SELECT COUNT(*) as count FROM training_applications WHERE status = 'kutilmoqda'");
$pending_training_apps_count = ($pending_training_apps_query) ? mysqli_fetch_assoc($pending_training_apps_query)['count'] : 0;

$total_matches_query = mysqli_query($conn, "SELECT COUNT(*) as count FROM matches WHERE status = 'rejalashtirilgan' AND match_date >= NOW()");
$upcoming_matches_count = ($total_matches_query) ? mysqli_fetch_assoc($total_matches_query)['count'] : 0;

?>

<h2 class="page-title">Boshqaruv Paneli</h2>
<p>Xush kelibsiz, <strong><?php echo htmlspecialchars($_SESSION['admin_username']); ?></strong>!</p>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
    <div class="card">
        <h3><a href="manage_tickets.php" style="text-decoration:none; color:inherit;">Chipta Arizalari</a></h3>
        <p>Kutilayotgan arizalar: <strong><?php echo $pending_tickets_count; ?></strong></p>
        <a href="manage_tickets.php" class="btn">Barcha Arizalar</a>
    </div>
    <div class="card">
        <h3><a href="manage_training_apps.php" style="text-decoration:none; color:inherit;">Mashg'ulot Arizalari</a></h3>
        <p>Kutilayotgan arizalar: <strong><?php echo $pending_training_apps_count; ?></strong></p>
        <a href="manage_training_apps.php" class="btn">Barcha Arizalar</a>
    </div>
    <div class="card">
        <h3><a href="manage_matches.php" style="text-decoration:none; color:inherit;">Kelgusi O'yinlar</a></h3>
        <p>Rejalashtirilgan o'yinlar: <strong><?php echo $upcoming_matches_count; ?></strong></p>
        <a href="manage_matches.php" class="btn">O'yinlarni Boshqarish</a>
    </div>
     <div class="card">
        <h3><a href="manage_team.php" style="text-decoration:none; color:inherit;">Jamoa Ma'lumotlari</a></h3>
        <p>Jamoa, o'yinchilar va ligalar.</p>
        <a href="manage_team.php" class="btn">Jamoani Boshqarish</a>
    </div>
    <div class="card">
        <h3><a href="manage_training_sessions.php" style="text-decoration:none; color:inherit;">Mashg'ulot Turlari</a></h3>
        <p>Mashg'ulotlarni qo'shish va tahrirlash.</p>
        <a href="manage_training_sessions.php" class="btn">Mashg'ulotlarni Boshqarish</a>
    </div>
</div>

<?php include 'includes/_admin_footer.php'; ?>