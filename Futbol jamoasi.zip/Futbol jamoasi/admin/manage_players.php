<?php
$page_title = "O'yinchilarni Boshqarish";
include 'includes/_admin_header.php';

$action = $_GET['action'] ?? 'list';
$player_id = $_GET['id'] ?? null;


if ($action == 'delete' && $player_id) {
    if (isset($_POST['confirm_delete'])) {
        
        $img_query = mysqli_query($conn, "SELECT image_url FROM players WHERE id = " . intval($player_id));
        if ($img_row = mysqli_fetch_assoc($img_query)) {
            if (!empty($img_row['image_url']) && $img_row['image_url'] != 'images/player_placeholder.png' && file_exists('../' . $img_row['image_url'])) {
                unlink('../' . $img_row['image_url']);
            }
        }

        $delete_sql = "DELETE FROM players WHERE id = ?";
        $stmt = mysqli_prepare($conn, $delete_sql);
        mysqli_stmt_bind_param($stmt, "i", $player_id);
        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['message'] = "O'yinchi muvaffaqiyatli o'chirildi.";
            $_SESSION['message_type'] = "success";
        } else {
            $_SESSION['message'] = "O'yinchini o'chirishda xatolik: " . mysqli_error($conn);
            $_SESSION['message_type'] = "error";
        }
        mysqli_stmt_close($stmt);
        header("Location: manage_players.php");
        exit;
    }
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_player'])) {
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $position = mysqli_real_escape_string($conn, $_POST['position']);
    $jersey_number = !empty($_POST['jersey_number']) ? intval($_POST['jersey_number']) : NULL;
    $date_of_birth = !empty($_POST['date_of_birth']) ? mysqli_real_escape_string($conn, $_POST['date_of_birth']) : NULL;
    $nationality = mysqli_real_escape_string($conn, $_POST['nationality']);
    $player_id_to_save = $_POST['player_id'] ?? null;
    $current_image_url = $_POST['current_image_url'] ?? 'images/player_placeholder.png';
    $image_url = $current_image_url; 

  
    if (isset($_FILES['player_image']) && $_FILES['player_image']['error'] == UPLOAD_ERR_OK) {
        $upload_dir = '../images/players/'; 
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        $file_extension = pathinfo($_FILES['player_image']['name'], PATHINFO_EXTENSION);
        $safe_filename = preg_replace('/[^A-Za-z0-9_.-]+/', '-', $full_name) . '_' . time() . '.' . $file_extension;
        $target_file = $upload_dir . $safe_filename;

        if (move_uploaded_file($_FILES['player_image']['tmp_name'], $target_file)) {
         
            if ($current_image_url != 'images/player_placeholder.png' && file_exists('../' . $current_image_url)) {
                 if ($current_image_url != $target_file) unlink('../' . $current_image_url);
            }
            $image_url = 'images/players/' . $safe_filename; 
        } else {
            $_SESSION['message'] = "Rasmni yuklashda xatolik yuz berdi.";
            $_SESSION['message_type'] = "error";
            
        }
    }


    if (empty($full_name)) {
        $_SESSION['message'] = "Iltimos, o'yinchining to'liq ismini kiriting.";
        $_SESSION['message_type'] = "error";
    } else {
        if ($player_id_to_save) { 
            $sql = "UPDATE players SET full_name=?, position=?, jersey_number=?, date_of_birth=?, nationality=?, image_url=? WHERE id=?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ssisssi", $full_name, $position, $jersey_number, $date_of_birth, $nationality, $image_url, $player_id_to_save);
        } else { 
            $sql = "INSERT INTO players (full_name, position, jersey_number, date_of_birth, nationality, image_url) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ssisss", $full_name, $position, $jersey_number, $date_of_birth, $nationality, $image_url);
        }

        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['message'] = "O'yinchi ma'lumotlari muvaffaqiyatli saqlandi.";
            $_SESSION['message_type'] = "success";
        } else {
            $_SESSION['message'] = "Xatolik: " . mysqli_error($conn);
            $_SESSION['message_type'] = "error";
        }
        mysqli_stmt_close($stmt);
        header("Location: manage_players.php");
        exit;
    }
}


$player_data = null;
if (($action == 'edit' || $action == 'delete') && $player_id) {
    $stmt = mysqli_prepare($conn, "SELECT * FROM players WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $player_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $player_data = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);
     if (!$player_data && $action != 'add') {
        $_SESSION['message'] = "O'yinchi topilmadi.";
        $_SESSION['message_type'] = "error";
        header("Location: manage_players.php");
        exit;
    }
}

?>

<h2 class="page-title">O'yinchilarni Boshqarish</h2>
<p><a href="manage_team.php" class="btn btn-secondary btn-sm">&laquo; Jamoani Boshqarishga Qaytish</a></p>


<?php if ($action == 'add' || ($action == 'edit' && $player_data)): ?>
    <div class="card">
        <h3><?php echo $action == 'add' ? "Yangi O'yinchi Qo'shish" : "O'yinchini Tahrirlash"; ?></h3>
        <form method="POST" action="manage_players.php" enctype="multipart/form-data">
            <?php if ($action == 'edit'): ?>
                <input type="hidden" name="player_id" value="<?php echo $player_data['id']; ?>">
                <input type="hidden" name="current_image_url" value="<?php echo htmlspecialchars($player_data['image_url'] ?? 'images/player_placeholder.png'); ?>">
            <?php endif; ?>

            <div class="form-group">
                <label for="full_name">To'liq Ismi:</label>
                <input type="text" id="full_name" name="full_name" value="<?php echo htmlspecialchars($player_data['full_name'] ?? ''); ?>" required>
            </div>
            <div class="form-group">
                <label for="position">Pozitsiyasi:</label>
                <input type="text" id="position" name="position" value="<?php echo htmlspecialchars($player_data['position'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label for="jersey_number">Futbolka Raqami:</label>
                <input type="number" id="jersey_number" name="jersey_number" value="<?php echo htmlspecialchars($player_data['jersey_number'] ?? ''); ?>" min="1">
            </div>
            <div class="form-group">
                <label for="date_of_birth">Tug'ilgan Sanasi:</label>
                <input type="date" id="date_of_birth" name="date_of_birth" value="<?php echo htmlspecialchars($player_data['date_of_birth'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label for="nationality">Millati:</label>
                <input type="text" id="nationality" name="nationality" value="<?php echo htmlspecialchars($player_data['nationality'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label for="player_image">O'yinchi Rasmi:</label>
                <input type="file" id="player_image" name="player_image" accept="image/*">
                <?php if ($action == 'edit' && !empty($player_data['image_url'])): ?>
                    <p style="margin-top:5px;">Joriy rasm: <br>
                        <img src="../<?php echo htmlspecialchars($player_data['image_url']); ?>" alt="<?php echo htmlspecialchars($player_data['full_name']); ?>" style="max-width: 100px; max-height: 100px; margin-top:5px;">
                    </p>
                <?php endif; ?>
                 <small>Agar rasm o'zgartirilmasa, joriy rasm saqlanib qoladi.</small>
            </div>

            <button type="submit" name="save_player" class="btn btn-success">Saqlash</button>
            <a href="manage_players.php" class="btn btn-secondary">Bekor Qilish</a>
        </form>
    </div>
<?php elseif ($action == 'delete' && $player_data): ?>
    <div class="card">
        <h3>O'yinchini O'chirishni Tasdiqlang</h3>
        <p>Haqiqatan ham <strong><?php echo htmlspecialchars($player_data['full_name']); ?></strong>ni o'yinchilar ro'yxatidan o'chirmoqchimisiz?</p>
        <form method="POST" action="manage_players.php?action=delete&id=<?php echo $player_data['id']; ?>">
            <button type="submit" name="confirm_delete" class="btn btn-danger">Ha, O'chirish</button>
            <a href="manage_players.php" class="btn btn-secondary">Yo'q, Bekor Qilish</a>
        </form>
    </div>
<?php endif; ?>


<?php if ($action == 'list'): ?>
    <div class="admin-actions">
        <a href="manage_players.php?action=add" class="btn btn-success">Yangi O'yinchi Qo'shish</a>
    </div>
    <div class="card">
        <h3>Mavjud O'yinchilar Ro'yxati</h3>
        <?php
        $players_sql = "SELECT * FROM players ORDER BY full_name ASC";
        $players_result = mysqli_query($conn, $players_sql);
        ?>
        <?php if (mysqli_num_rows($players_result) > 0): ?>
            <table class="styled-table">
                <thead>
                    <tr>
                        <th>Rasm</th>
                        <th>Ismi</th>
                        <th>Pozitsiyasi</th>
                        <th>Raqami</th>
                        <th>Tug'ilgan Sana</th>
                        <th>Millati</th>
                        <th>Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($player = mysqli_fetch_assoc($players_result)): ?>
                        <tr>
                            <td>
                                <img src="../<?php echo htmlspecialchars(!empty($player['image_url']) ? $player['image_url'] : 'images/player_placeholder.png'); ?>" alt="<?php echo htmlspecialchars($player['full_name']); ?>" style="width: 50px; height: 50px; object-fit: cover; border-radius: 50%;">
                            </td>
                            <td><?php echo htmlspecialchars($player['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($player['position']); ?></td>
                            <td><?php echo htmlspecialchars($player['jersey_number']); ?></td>
                            <td><?php echo format_date_only_uz($player['date_of_birth']); ?></td>
                            <td><?php echo htmlspecialchars($player['nationality']); ?></td>
                            <td class="actions">
                                <a href="manage_players.php?action=edit&id=<?php echo $player['id']; ?>" class="edit-btn">Tahrir</a>
                                <a href="manage_players.php?action=delete&id=<?php echo $player['id']; ?>" class="delete-btn">O'chirish</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Hozircha o'yinchilar kiritilmagan.</p>
        <?php endif; ?>
    </div>
<?php endif; ?>

<?php include 'includes/_admin_footer.php'; ?>