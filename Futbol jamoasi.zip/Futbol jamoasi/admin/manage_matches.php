<?php
$page_title = "O'yinlarni Boshqarish";
include 'includes/_admin_header.php'; 

$our_team_name_result = mysqli_query($conn, "SELECT name FROM team_info LIMIT 1");
$our_team_name = ($our_team_name_result && mysqli_num_rows($our_team_name_result) > 0) ? mysqli_fetch_assoc($our_team_name_result)['name'] : 'FC Jasorat';



$action = $_GET['action'] ?? 'list'; 
$match_id = $_GET['id'] ?? null;

// O'yinni o'chirish
if ($action == 'delete' && $match_id) {
    if (isset($_POST['confirm_delete'])) {
        $delete_sql = "DELETE FROM matches WHERE id = ?";
        $stmt = mysqli_prepare($conn, $delete_sql);
        mysqli_stmt_bind_param($stmt, "i", $match_id);
        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['message'] = "O'yin muvaffaqiyatli o'chirildi.";
            $_SESSION['message_type'] = "success";
        } else {
            $_SESSION['message'] = "O'yinni o'chirishda xatolik: " . mysqli_error($conn);
            $_SESSION['message_type'] = "error";
        }
        mysqli_stmt_close($stmt);
        header("Location: manage_matches.php");
        exit;
    }
}



if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_match'])) {
    $home_team_name = mysqli_real_escape_string($conn, $_POST['home_team_name']);
    $away_team_name = mysqli_real_escape_string($conn, $_POST['away_team_name']);
    $match_date = mysqli_real_escape_string($conn, $_POST['match_date']);
    $venue = mysqli_real_escape_string($conn, $_POST['venue']);
    $league_id = !empty($_POST['league_id']) ? intval($_POST['league_id']) : NULL;
    $home_score = !empty($_POST['home_score']) || $_POST['home_score'] === '0' ? intval($_POST['home_score']) : NULL;
    $away_score = !empty($_POST['away_score']) || $_POST['away_score'] === '0' ? intval($_POST['away_score']) : NULL;
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $ticket_price = !empty($_POST['ticket_price']) ? floatval($_POST['ticket_price']) : 0.00;
    $our_team_is_home = ($home_team_name == $our_team_name); 

    $match_id_to_save = $_POST['match_id'] ?? null;

    if (empty($home_team_name) || empty($away_team_name) || empty($match_date) || empty($venue) || empty($status)) {
        $_SESSION['message'] = "Iltimos, barcha majburiy maydonlarni to'ldiring.";
        $_SESSION['message_type'] = "error";
    } else {
        if ($match_id_to_save) { // Tahrirlash
            $sql = "UPDATE matches SET home_team_name=?, away_team_name=?, match_date=?, venue=?, league_id=?, home_score=?, away_score=?, status=?, ticket_price=?, our_team_is_home=? WHERE id=?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ssssiiisdii", $home_team_name, $away_team_name, $match_date, $venue, $league_id, $home_score, $away_score, $status, $ticket_price, $our_team_is_home, $match_id_to_save);
        } else { // Qo'shish
            $sql = "INSERT INTO matches (home_team_name, away_team_name, match_date, venue, league_id, home_score, away_score, status, ticket_price, our_team_is_home) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ssssiiisdi", $home_team_name, $away_team_name, $match_date, $venue, $league_id, $home_score, $away_score, $status, $ticket_price, $our_team_is_home);
        }

        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['message'] = "O'yin ma'lumotlari muvaffaqiyatli saqlandi.";
            $_SESSION['message_type'] = "success";
        } else {
            $_SESSION['message'] = "Xatolik: " . mysqli_error($conn);
            $_SESSION['message_type'] = "error";
        }
        mysqli_stmt_close($stmt);
        header("Location: manage_matches.php");
        exit;
    }
}


$leagues_result = mysqli_query($conn, "SELECT id, name FROM leagues ORDER BY name");
$leagues = [];
if ($leagues_result) {
    while ($row = mysqli_fetch_assoc($leagues_result)) {
        $leagues[] = $row;
    }
}

$match_data = null;
if (($action == 'edit' || $action == 'delete') && $match_id) {
    $stmt = mysqli_prepare($conn, "SELECT * FROM matches WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $match_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $match_data = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);
    if (!$match_data && $action != 'add') { 
        $_SESSION['message'] = "O'yin topilmadi.";
        $_SESSION['message_type'] = "error";
        header("Location: manage_matches.php");
        exit;
    }
}
?>

<h2 class="page-title">O'yinlarni Boshqarish</h2>

<?php if ($action == 'add' || ($action == 'edit' && $match_data)): ?>
    <div class="card">
        <h3><?php echo $action == 'add' ? "Yangi O'yin Qo'shish" : "O'yinni Tahrirlash"; ?></h3>
        <form method="POST" action="manage_matches.php">
            <?php if ($action == 'edit'): ?>
                <input type="hidden" name="match_id" value="<?php echo $match_data['id']; ?>">
            <?php endif; ?>

            <div class="form-group">
                <label for="home_team_name">Uy Jamoasi Nomi:</label>
                <input type="text" id="home_team_name" name="home_team_name" value="<?php echo htmlspecialchars($match_data['home_team_name'] ?? $our_team_name); ?>" required>
                <small>Agar bizning jamoa uyda o'ynasa, jamoa nomini to'g'ri kiriting (<?php echo htmlspecialchars($our_team_name); ?>).</small>
            </div>
            <div class="form-group">
                <label for="away_team_name">Mehmon Jamoa Nomi:</label>
                <input type="text" id="away_team_name" name="away_team_name" value="<?php echo htmlspecialchars($match_data['away_team_name'] ?? ''); ?>" required>
                 <small>Agar bizning jamoa mehmonda o'ynasa, jamoa nomini to'g'ri kiriting (<?php echo htmlspecialchars($our_team_name); ?>).</small>
            </div>
            <div class="form-group">
                <label for="match_date">O'yin Sanasi va Vaqti:</label>
                <input type="datetime-local" id="match_date" name="match_date" value="<?php echo htmlspecialchars(isset($match_data['match_date']) ? date('Y-m-d\TH:i', strtotime($match_data['match_date'])) : ''); ?>" required>
            </div>
            <div class="form-group">
                <label for="venue">O'yin O'tkaziladigan Joy:</label>
                <input type="text" id="venue" name="venue" value="<?php echo htmlspecialchars($match_data['venue'] ?? ''); ?>" required>
            </div>
            <div class="form-group">
                <label for="league_id">Liga:</label>
                <select id="league_id" name="league_id">
                    <option value="">Tanlanmagan (O'rtoqlik)</option>
                    <?php foreach ($leagues as $league): ?>
                        <option value="<?php echo $league['id']; ?>" <?php echo (isset($match_data['league_id']) && $match_data['league_id'] == $league['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($league['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
             <div class="form-group">
                <label for="status">Holati:</label>
                <select id="status" name="status" required>
                    <option value="rejalashtirilgan" <?php echo (isset($match_data['status']) && $match_data['status'] == 'rejalashtirilgan') ? 'selected' : ''; ?>>Rejalashtirilgan</option>
                    <option value="oʻynalgan" <?php echo (isset($match_data['status']) && $match_data['status'] == 'oʻynalgan') ? 'selected' : ''; ?>>O'ynalgan</option>
                    <option value="bekor qilingan" <?php echo (isset($match_data['status']) && $match_data['status'] == 'bekor qilingan') ? 'selected' : ''; ?>>Bekor Qilingan</option>
                </select>
            </div>
            <div class="form-group">
                <label for="home_score">Uy Jamoasi Hisobi (agar o'ynalgan bo'lsa):</label>
                <input type="number" id="home_score" name="home_score" value="<?php echo htmlspecialchars($match_data['home_score'] ?? ''); ?>" min="0">
            </div>
            <div class="form-group">
                <label for="away_score">Mehmon Jamoa Hisobi (agar o'ynalgan bo'lsa):</label>
                <input type="number" id="away_score" name="away_score" value="<?php echo htmlspecialchars($match_data['away_score'] ?? ''); ?>" min="0">
            </div>
            <div class="form-group">
                <label for="ticket_price">Chipta Narxi (so'mda, 0 agar bepul yoki sotuvda bo'lmasa):</label>
                <input type="number" step="0.01" id="ticket_price" name="ticket_price" value="<?php echo htmlspecialchars($match_data['ticket_price'] ?? '0.00'); ?>" min="0">
            </div>
            <button type="submit" name="save_match" class="btn btn-success">Saqlash</button>
            <a href="manage_matches.php" class="btn btn-secondary">Bekor Qilish</a>
        </form>
    </div>

<?php elseif ($action == 'delete' && $match_data): ?>
    <div class="card">
        <h3>O'yinni O'chirishni Tasdiqlang</h3>
        <p>Haqiqatan ham ushbu o'yinni o'chirmoqchimisiz?</p>
        <p>
            <strong><?php echo htmlspecialchars($match_data['home_team_name']); ?> vs <?php echo htmlspecialchars($match_data['away_team_name']); ?></strong><br>
            Sana: <?php echo format_date_uz($match_data['match_date']); ?><br>
            Manzil: <?php echo htmlspecialchars($match_data['venue']); ?>
        </p>
        <form method="POST" action="manage_matches.php?action=delete&id=<?php echo $match_data['id']; ?>">
            <button type="submit" name="confirm_delete" class="btn btn-danger">Ha, O'chirish</button>
            <a href="manage_matches.php" class="btn btn-secondary">Yo'q, Bekor Qilish</a>
        </form>
    </div>
<?php endif; ?>


<?php if ($action == 'list'): ?>
    <div class="admin-actions">
        <a href="manage_matches.php?action=add" class="btn btn-success">Yangi O'yin Qo'shish</a>
    </div>
    <div class="card">
        <h3>Mavjud O'yinlar Ro'yxati</h3>
        <?php
        $matches_sql = "SELECT m.*, l.name as league_name 
                        FROM matches m 
                        LEFT JOIN leagues l ON m.league_id = l.id 
                        ORDER BY m.match_date DESC";
        $matches_result = mysqli_query($conn, $matches_sql);
        ?>
        <?php if (mysqli_num_rows($matches_result) > 0): ?>
            <table class="styled-table">
                <thead>
                    <tr>
                        <th>Uy Jamoasi</th>
                        <th>Mehmon Jamoasi</th>
                        <th>Sana</th>
                        <th>Manzil</th>
                        <th>Liga</th>
                        <th>Hisob</th>
                        <th>Holati</th>
                        <th>Chipta Narxi</th>
                        <th>Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($match = mysqli_fetch_assoc($matches_result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($match['home_team_name']); ?></td>
                            <td><?php echo htmlspecialchars($match['away_team_name']); ?></td>
                            <td><?php echo format_date_uz($match['match_date']); ?></td>
                            <td><?php echo htmlspecialchars($match['venue']); ?></td>
                            <td><?php echo htmlspecialchars($match['league_name'] ?? 'N/A'); ?></td>
                            <td><?php echo ($match['status'] == 'oʻynalgan') ? (htmlspecialchars($match['home_score'] ?? '-') . ' : ' . htmlspecialchars($match['away_score'] ?? '-')) : 'N/A'; ?></td>
                            <td><?php echo htmlspecialchars(ucfirst($match['status'])); ?></td>
                            <td><?php echo number_format($match['ticket_price'], 0, '.', ' '); ?> so'm</td>
                            <td class="actions">
                                <a href="manage_matches.php?action=edit&id=<?php echo $match['id']; ?>" class="edit-btn">Tahrir</a>
                                <a href="manage_matches.php?action=delete&id=<?php echo $match['id']; ?>" class="delete-btn">O'chirish</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Hozircha o'yinlar kiritilmagan.</p>
        <?php endif; ?>
    </div>
<?php endif; ?>

<?php include 'includes/_admin_footer.php'; ?>