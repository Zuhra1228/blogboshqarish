<?php
$page_title = "Mashg'ulot Turlarini Boshqarish";
include 'includes/_admin_header.php';

$action = $_GET['action'] ?? 'list';
$session_id = $_GET['id'] ?? null;


if ($action == 'delete' && $session_id) {
    if (isset($_POST['confirm_delete'])) {
       
        $delete_sql = "DELETE FROM training_sessions WHERE id = ?";
        $stmt = mysqli_prepare($conn, $delete_sql);
        mysqli_stmt_bind_param($stmt, "i", $session_id);
        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['message'] = "Mashg'ulot turi muvaffaqiyatli o'chirildi.";
            $_SESSION['message_type'] = "success";
        } else {
            $_SESSION['message'] = "Mashg'ulot turini o'chirishda xatolik: " . mysqli_error($conn);
            $_SESSION['message_type'] = "error";
        }
        mysqli_stmt_close($stmt);
        header("Location: manage_training_sessions.php");
        exit;
    }
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_session'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $price_monthly = floatval($_POST['price_monthly']);
    $schedule_details = mysqli_real_escape_string($conn, $_POST['schedule_details']);
    $age_group = mysqli_real_escape_string($conn, $_POST['age_group']);
    $session_id_to_save = $_POST['session_id'] ?? null;

    if (empty($name) || $price_monthly < 0) {
        $_SESSION['message'] = "Iltimos, barcha majburiy maydonlarni to'g'ri to'ldiring.";
        $_SESSION['message_type'] = "error";
    } else {
        if ($session_id_to_save) { 
            $sql = "UPDATE training_sessions SET name=?, description=?, price_monthly=?, schedule_details=?, age_group=? WHERE id=?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ssdssi", $name, $description, $price_monthly, $schedule_details, $age_group, $session_id_to_save);
        } else { 
            $sql = "INSERT INTO training_sessions (name, description, price_monthly, schedule_details, age_group) VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ssdss", $name, $description, $price_monthly, $schedule_details, $age_group);
        }

        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['message'] = "Mashg'ulot turi ma'lumotlari muvaffaqiyatli saqlandi.";
            $_SESSION['message_type'] = "success";
        } else {
            $_SESSION['message'] = "Xatolik: " . mysqli_error($conn);
            $_SESSION['message_type'] = "error";
        }
        mysqli_stmt_close($stmt);
        header("Location: manage_training_sessions.php");
        exit;
    }
}

$session_data = null;
if (($action == 'edit' || $action == 'delete') && $session_id) {
    $stmt = mysqli_prepare($conn, "SELECT * FROM training_sessions WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $session_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $session_data = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);
    if (!$session_data && $action != 'add') {
        $_SESSION['message'] = "Mashg'ulot turi topilmadi.";
        $_SESSION['message_type'] = "error";
        header("Location: manage_training_sessions.php");
        exit;
    }
}
?>

<h2 class="page-title">Mashg'ulot Turlarini Boshqarish</h2>

<?php if ($action == 'add' || ($action == 'edit' && $session_data)): ?>
    <div class="card">
        <h3><?php echo $action == 'add' ? "Yangi Mashg'ulot Turi Qo'shish" : "Mashg'ulot Turini Tahrirlash"; ?></h3>
        <form method="POST" action="manage_training_sessions.php">
            <?php if ($action == 'edit'): ?>
                <input type="hidden" name="session_id" value="<?php echo $session_data['id']; ?>">
            <?php endif; ?>

            <div class="form-group">
                <label for="name">Mashg'ulot Nomi:</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($session_data['name'] ?? ''); ?>" required>
            </div>
            <div class="form-group">
                <label for="description">Tavsifi:</label>
                <textarea id="description" name="description" rows="3"><?php echo htmlspecialchars($session_data['description'] ?? ''); ?></textarea>
            </div>
            <div class="form-group">
                <label for="price_monthly">Oylik Narxi (so'm):</label>
                <input type="number" step="0.01" id="price_monthly" name="price_monthly" value="<?php echo htmlspecialchars($session_data['price_monthly'] ?? '0.00'); ?>" required min="0">
            </div>
            <div class="form-group">
                <label for="schedule_details">Dars Jadvali (masalan, "Haftada 3 marta, D-Ch-J, 16:00-18:00"):</label>
                <input type="text" id="schedule_details" name="schedule_details" value="<?php echo htmlspecialchars($session_data['schedule_details'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label for="age_group">Yosh Guruhi (masalan, "7-10 yosh"):</label>
                <input type="text" id="age_group" name="age_group" value="<?php echo htmlspecialchars($session_data['age_group'] ?? ''); ?>">
            </div>
            <button type="submit" name="save_session" class="btn btn-success">Saqlash</button>
            <a href="manage_training_sessions.php" class="btn btn-secondary">Bekor Qilish</a>
        </form>
    </div>

<?php elseif ($action == 'delete' && $session_data): ?>
    <div class="card">
        <h3>Mashg'ulot Turini O'chirishni Tasdiqlang</h3>
        <p>Haqiqatan ham <strong><?php echo htmlspecialchars($session_data['name']); ?></strong> nomli mashg'ulot turini o'chirmoqchimisiz?</p>
        <p><small>Diqqat: Bu mashg'ulot turiga yozilgan barcha arizalar ham o'chirilishi mumkin (agar ma'lumotlar bazasida shunday sozlanmagan bo'lsa, arizalar bog'liqligi saqlanib qoladi va xatolik kelib chiqishi mumkin).</small></p>
        <form method="POST" action="manage_training_sessions.php?action=delete&id=<?php echo $session_data['id']; ?>">
            <button type="submit" name="confirm_delete" class="btn btn-danger">Ha, O'chirish</button>
            <a href="manage_training_sessions.php" class="btn btn-secondary">Yo'q, Bekor Qilish</a>
        </form>
    </div>
<?php endif; ?>


<?php if ($action == 'list'): ?>
    <div class="admin-actions">
        <a href="manage_training_sessions.php?action=add" class="btn btn-success">Yangi Mashg'ulot Turi Qo'shish</a>
    </div>
    <div class="card">
        <h3>Mavjud Mashg'ulot Turlari Ro'yxati</h3>
        <?php
        $sessions_sql = "SELECT * FROM training_sessions ORDER BY name ASC";
        $sessions_result = mysqli_query($conn, $sessions_sql);
        ?>
        <?php if (mysqli_num_rows($sessions_result) > 0): ?>
            <table class="styled-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nomi</th>
                        <th>Narxi (oylik)</th>
                        <th>Yosh Guruhi</th>
                        <th>Jadval</th>
                        <th>Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($session = mysqli_fetch_assoc($sessions_result)): ?>
                        <tr>
                            <td><?php echo $session['id']; ?></td>
                            <td><?php echo htmlspecialchars($session['name']); ?></td>
                            <td><?php echo number_format($session['price_monthly'], 0, '.', ' '); ?> so'm</td>
                            <td><?php echo htmlspecialchars($session['age_group']); ?></td>
                            <td><?php echo htmlspecialchars($session['schedule_details']); ?></td>
                            <td class="actions">
                                <a href="manage_training_sessions.php?action=edit&id=<?php echo $session['id']; ?>" class="edit-btn">Tahrir</a>
                                <a href="manage_training_sessions.php?action=delete&id=<?php echo $session['id']; ?>" class="delete-btn">O'chirish</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Hozircha mashg'ulot turlari kiritilmagan.</p>
        <?php endif; ?>
    </div>
<?php endif; ?>

<?php include 'includes/_admin_footer.php'; ?>