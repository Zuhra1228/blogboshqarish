</div>
    </main>
    <footer>
        <div class="container">
            <p>&copy; <?php echo date("Y"); ?> Admin Panel. <a href="../index.php" style="color:#fcb42d;">Saytga o'tish</a></p>
        </div>
    </footer>
    <?php if (isset($extra_js)): ?>
        <?php foreach ($extra_js as $js_file): ?>
            <script src="<?php echo $js_file; ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>
<?php if (isset($conn)) mysqli_close($conn);  ?>