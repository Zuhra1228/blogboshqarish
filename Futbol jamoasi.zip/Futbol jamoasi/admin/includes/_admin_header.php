<?php
require_once '../config.php'; // Asosiy papkadagi config.php
ensure_admin_logged_in(); // Admin kirganligini tekshirish
$conn = db_connect(); // Har bir admin sahifasi uchun ulanish

$admin_page_title = $page_title ?? "Admin Panel";
$current_admin_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $admin_page_title; ?></title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Asosiy CSS -->
    <style>
        /* Admin paneliga xos qo'shimcha uslublar */
        .admin-header {
            background-color: #343a40;
            color: #fff;
            padding: 10px 0;
        }
        .admin-header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .admin-header h1 {
            font-size: 1.5em; margin:0;
        }
        .admin-header h1 a { color: #fff; text-decoration:none; }
        .admin-nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
        }
        .admin-nav ul li {
            margin-left: 15px;
        }
        .admin-nav ul li a {
            color: #f8f9fa;
            text-decoration: none;
            padding: 8px 10px;
            border-radius: 4px;
        }
        .admin-nav ul li a:hover,
        .admin-nav ul li a.active {
            background-color: #495057;
        }
        .admin-nav ul li a.logout-btn {
            background-color: #dc3545;
            color: white;
        }
         .admin-nav ul li a.logout-btn:hover {
            background-color: #c82333;
        }
        .admin-main { padding: 20px; }
        .admin-main .page-title {
            color: #343a40;
            border-bottom-color: #343a40;
        }
        .admin-actions { margin-bottom: 20px; }
        .admin-actions .btn { margin-right: 10px; }
    </style>
     <?php if (isset($extra_css)): ?>
        <?php foreach ($extra_css as $css_file): ?>
            <link rel="stylesheet" href="<?php echo $css_file; ?>">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body>
    <header class="admin-header">
        <div class="container">
            <h1><a href="dashboard.php">Admin Panel</a></h1>
            <nav class="admin-nav">
                <ul>
                    <li><a href="dashboard.php" class="<?php echo ($current_admin_page == 'dashboard.php') ? 'active' : ''; ?>">Boshqaruv Paneli</a></li>
                    <li><a href="manage_matches.php" class="<?php echo ($current_admin_page == 'manage_matches.php') ? 'active' : ''; ?>">O'yinlarni Boshqarish</a></li>
                    <li><a href="manage_team.php" class="<?php echo ($current_admin_page == 'manage_team.php') ? 'active' : ''; ?>">Jamoani Boshqarish</a></li>
                    <li><a href="manage_tickets.php" class="<?php echo ($current_admin_page == 'manage_tickets.php') ? 'active' : ''; ?>">Chipta Arizalari</a></li>
                    <li><a href="manage_training_apps.php" class="<?php echo ($current_admin_page == 'manage_training_apps.php') ? 'active' : ''; ?>">Mashg'ulot Arizalari</a></li>
                    <li><a href="manage_training_sessions.php" class="<?php echo ($current_admin_page == 'manage_training_sessions.php') ? 'active' : ''; ?>">Mashg'ulot Turlari</a></li>
                    <li><a href="logout.php" class="logout-btn">Chiqish</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <main class="admin-main">
        <div class="container">
            <?php display_message(); // Xabarlarni ko'rsatish ?>