<?php
$page_title = "Jamoani Boshqarish";
include 'includes/_admin_header.php';


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_team_info'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $foundation_date = mysqli_real_escape_string($conn, $_POST['foundation_date']);
    $country = mysqli_real_escape_string($conn, $_POST['country']);
    $owner = mysqli_real_escape_string($conn, $_POST['owner']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    
    $logo_url = mysqli_real_escape_string($conn, $_POST['logo_url']);

   
    $check_sql = "SELECT id FROM team_info LIMIT 1";
    $check_result = mysqli_query($conn, $check_sql);

    if (mysqli_num_rows($check_result) > 0) {
        $team_id_row = mysqli_fetch_assoc($check_result);
        $team_id = $team_id_row['id'];
        $sql = "UPDATE team_info SET name=?, foundation_date=?, country=?, owner=?, description=?, logo_url=? WHERE id=?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssssssi", $name, $foundation_date, $country, $owner, $description, $logo_url, $team_id);
    } else {
        $sql = "INSERT INTO team_info (name, foundation_date, country, owner, description, logo_url) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssssss", $name, $foundation_date, $country, $owner, $description, $logo_url);
    }

    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['message'] = "Jamoa ma'lumotlari muvaffaqiyatli saqlandi.";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Xatolik: " . mysqli_error($conn);
        $_SESSION['message_type'] = "error";
    }
    mysqli_stmt_close($stmt);
    header("Location: manage_team.php");
    exit;
}


$team_info_query = mysqli_query($conn, "SELECT * FROM team_info LIMIT 1");
$team_info = mysqli_fetch_assoc($team_info_query);
if (!$team_info) { 
    $team_info = [
        'name' => '', 'foundation_date' => '', 'country' => '', 'owner' => '', 'description' => '', 'logo_url' => 'images/logo_placeholder.png'
    ];
}
?>

<h2 class="page-title">Jamoa Ma'lumotlarini Boshqarish</h2>

<div class="card">
    <h3>Asosiy Ma'lumotlar</h3>
    <form method="POST" action="manage_team.php">
        <div class="form-group">
            <label for="name">Jamoa Nomi:</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($team_info['name']); ?>" required>
        </div>
        <div class="form-group">
            <label for="foundation_date">Tashkil Topgan Sana:</label>
            <input type="date" id="foundation_date" name="foundation_date" value="<?php echo htmlspecialchars($team_info['foundation_date']); ?>">
        </div>
        <div class="form-group">
            <label for="country">Mamlakat:</label>
            <input type="text" id="country" name="country" value="<?php echo htmlspecialchars($team_info['country']); ?>">
        </div>
        <div class="form-group">
            <label for="owner">Jamoa Egasi:</label>
            <input type="text" id="owner" name="owner" value="<?php echo htmlspecialchars($team_info['owner']); ?>">
        </div>
        <div class="form-group">
            <label for="logo_url">Logotip URL manzili:</label>
            <input type="text" id="logo_url" name="logo_url" value="<?php echo htmlspecialchars($team_info['logo_url']); ?>">
           
             <?php if (!empty($team_info['logo_url']) && file_exists('../'.$team_info['logo_url'])): ?>
                <img src="../<?php echo htmlspecialchars($team_info['logo_url']); ?>" alt="Jamoa logotipi" style="max-width: 100px; margin-top: 10px;">
            <?php elseif(!empty($team_info['logo_url'])): ?>
                 <img src="../images/logo_placeholder.png" alt="Standart Logotip" style="max-width: 100px; margin-top: 10px;">
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label for="description">Jamoa Haqida Qo'shimcha Ma'lumot:</label>
            <textarea id="description" name="description" rows="5"><?php echo htmlspecialchars($team_info['description']); ?></textarea>
        </div>
        <button type="submit" name="save_team_info" class="btn btn-success">Saqlash</button>
    </form>
</div>


<div class="card" style="margin-top: 30px;">
    <h3><a href="manage_players.php" style="text-decoration:none; color:inherit;">O'yinchilarni Boshqarish</a></h3>
    <p>Jamoa tarkibidagi o'yinchilarni qo'shish, tahrirlash va o'chirish uchun quyidagi havolaga o'ting.</p>
    <a href="manage_players.php" class="btn">O'yinchilarga O'tish</a>
</div>

<


<?php include 'includes/_admin_footer.php'; ?>