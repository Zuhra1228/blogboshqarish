<?php
$page_title = "Chipta Arizalarini Boshqarish";
include 'includes/_admin_header.php';


if (isset($_GET['action']) && isset($_GET['id']) && isset($_GET['status'])) {
    $application_id = intval($_GET['id']);
    $new_status = mysqli_real_escape_string($conn, $_GET['status']);

    if ($new_status == 'tasdiqlangan' || $new_status == 'rad etilgan' || $new_status == 'kutilmoqda') {
        $update_sql = "UPDATE ticket_applications SET status = ? WHERE id = ?";
        $stmt = mysqli_prepare($conn, $update_sql);
        mysqli_stmt_bind_param($stmt, "si", $new_status, $application_id);
        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['message'] = "Ariza statusi muvaffaqiyatli o'zgartirildi.";
            $_SESSION['message_type'] = "success";
        } else {
            $_SESSION['message'] = "Statusni o'zgartirishda xatolik: " . mysqli_error($conn);
            $_SESSION['message_type'] = "error";
        }
        mysqli_stmt_close($stmt);
        header("Location: manage_tickets.php");
        exit;
    }
}


$applications_sql = "SELECT ta.*, m.home_team_name, m.away_team_name, m.match_date 
                     FROM ticket_applications ta
                     JOIN matches m ON ta.match_id = m.id
                     ORDER BY ta.application_date DESC";
$applications_result = mysqli_query($conn, $applications_sql);
?>

<h2 class="page-title">Chipta Sotib Olish Arizalari</h2>

<div class="card">
    <h3>Barcha Arizalar Ro'yxati</h3>
    <?php if (mysqli_num_rows($applications_result) > 0): ?>
        <table class="styled-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>O'yin</th>
                    <th>Sana</th>
                    <th>Foydalanuvchi</th>
                    <th>Email</th>
                    <th>Telefon</th>
                    <th>Soni</th>
                    <th>Ariza Sanasi</th>
                    <th>Holati</th>
                    <th>Amallar</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($app = mysqli_fetch_assoc($applications_result)): ?>
                    <tr>
                        <td><?php echo $app['id']; ?></td>
                        <td><?php echo htmlspecialchars($app['home_team_name'] . " vs " . $app['away_team_name']); ?></td>
                        <td><?php echo format_date_uz($app['match_date']); ?></td>
                        <td><?php echo htmlspecialchars($app['user_name']); ?></td>
                        <td><?php echo htmlspecialchars($app['user_email']); ?></td>
                        <td><?php echo htmlspecialchars($app['user_phone']); ?></td>
                        <td><?php echo $app['quantity']; ?></td>
                        <td><?php echo format_date_uz($app['application_date']); ?></td>
                        <td>
                            <span style="padding: 3px 7px; border-radius: 4px; color: white; background-color: <?php
                                echo $app['status'] == 'tasdiqlangan' ? '#28a745' : ($app['status'] == 'rad etilgan' ? '#dc3545' : '#ffc107; color:#333;');
                            ?>">
                                <?php echo ucfirst(htmlspecialchars($app['status'])); ?>
                            </span>
                        </td>
                        <td class="actions">
                            <?php if ($app['status'] == 'kutilmoqda'): ?>
                                <a href="manage_tickets.php?action=update_status&id=<?php echo $app['id']; ?>&status=tasdiqlangan" class="approve-btn">Tasdiqlash</a>
                                
                            <?php elseif ($app['status'] == 'tasdiqlangan'): ?>
                             
                                 <a href="manage_tickets.php?action=update_status&id=<?php echo $app['id']; ?>&status=kutilmoqda" class="edit-btn" style="background-color:#ffc107; color:#333;">Kutilmoqda</a>
                            <?php elseif ($app['status'] == 'rad etilgan'): ?>
                                <a href="manage_tickets.php?action=update_status&id=<?php echo $app['id']; ?>&status=tasdiqlangan" class="approve-btn">Tasdiqlash</a>
                                 <a href="manage_tickets.php?action=update_status&id=<?php echo $app['id']; ?>&status=kutilmoqda" class="edit-btn" style="background-color:#ffc107; color:#333;">Kutilmoqda</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Hozircha chipta uchun arizalar mavjud emas.</p>
    <?php endif; ?>
</div>

<?php include 'includes/_admin_footer.php'; ?>