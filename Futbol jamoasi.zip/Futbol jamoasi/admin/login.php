<?php
require_once '../config.php'; 

$page_title = "Admin Paneliga Kirish";

define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', 'admin123'); 

if (is_admin_logged_in()) {
    header("Location: dashboard.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username_attempt = $_POST['username'];
    $password_attempt = $_POST['password'];

    if ($username_attempt === ADMIN_USERNAME && $password_attempt === ADMIN_PASSWORD) {
       
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = ADMIN_USERNAME;
       
        $_SESSION['message'] = "Xush kelibsiz, " . htmlspecialchars(ADMIN_USERNAME) . "!";
        $_SESSION['message_type'] = "success";
        header("Location: dashboard.php");
        exit;
    } else {
        $_SESSION['message'] = "Login yoki parol noto'g'ri.";
        $_SESSION['message_type'] = "error";
    }
   
    header("Location: login.php"); 
    exit;
}

?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="../css/style.css"> 
    <style>
        body {
            background-color: #e9ecef;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin:0;
        }
        .login-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }
        .login-container h2 {
            text-align: center;
            color: #0a2463;
            margin-bottom: 25px;
        }
        .form-group input[type="text"],
        .form-group input[type="password"] {
            background-color: #f8f9fa;
        }
        .btn {
            width: 100%;
            padding: 12px;
            font-size: 1.1em;
        }
        .message { margin-top: 0; } 
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Admin Paneliga Kirish</h2>
        <?php display_message();  ?>
        <form method="POST" action="login.php">
            <div class="form-group">
                <label for="username">Login:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Parol:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" class="btn">Kirish</button>
        </form>
         <p style="text-align:center; margin-top:15px;"><a href="../index.php">Asosiy saytga qaytish</a></p>
    </div>
</body>
</html>