<?php
header("Location: jamoa_haqida.php");
exit;
?>