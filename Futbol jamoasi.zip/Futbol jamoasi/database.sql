CREATE DATABASE IF NOT EXISTS `jamoasi_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `jamoasi_db`;

CREATE TABLE `admins` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admins` (`username`, `password_hash`) VALUES
('admin', '$2y$10$N0UgI4.gA.XIF0fsvf.mU.5wZ5.Xf1qgU.N0gI5.gA.XIF0fsvf.mU'); 

CREATE TABLE `team_info` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL DEFAULT 'FC Jasorat',
  `foundation_date` DATE DEFAULT '2000-01-01',
  `country` VARCHAR(100) DEFAULT 'Oʻzbekiston',
  `owner` VARCHAR(100) DEFAULT 'Nomaʼlum',
  `logo_url` VARCHAR(255) DEFAULT 'images/logo_placeholder.png', 
  `description` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


INSERT INTO `team_info` (`name`, `foundation_date`, `country`, `owner`, `description`) VALUES
('FC Jasorat', '2005-03-15', 'Oʻzbekiston', 'Jasorat Futbol Klubi MCHJ', 'FC Jasorat - Oʻzbekistonning eng yorqin futbol klublaridan biri boʻlib, oʻzining matonati va gʻalabaga boʻlgan intilishi bilan mashhur. Klub yosh isteʼdodlarni kashf etish va ularni professional futbolchilarga aylantirishga katta eʼtibor qaratadi.');

CREATE TABLE `players` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `full_name` VARCHAR(100) NOT NULL,
  `position` VARCHAR(50),
  `jersey_number` INT,
  `date_of_birth` DATE,
  `nationality` VARCHAR(50),
  `image_url` VARCHAR(255) DEFAULT 'images/player_placeholder.png' 
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `players` (`full_name`, `position`, `jersey_number`, `date_of_birth`, `nationality`) VALUES
('Alisher Rustamov', 'Hujumchi', 9, '1995-07-20', 'Oʻzbekiston'),
('Sardor Komilov', 'Yarim himoyachi', 10, '1998-02-10', 'Oʻzbekiston'),
('Timur Akbarov', 'Himoyachi', 4, '1993-11-05', 'Oʻzbekiston'),
('Botir Zokirov', 'Darvozabon', 1, '1996-05-30', 'Oʻzbekiston');


CREATE TABLE `leagues` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `country` VARCHAR(100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


INSERT INTO `leagues` (`name`, `country`) VALUES
('Oʻzbekiston Superligasi', 'Oʻzbekiston'),
('Osiyo Chempionlar Ligasi', 'Osiyo');


CREATE TABLE `team_league_stats` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `team_id` INT DEFAULT 1, 
  `league_id` INT NOT NULL,
  `season_year` YEAR NOT NULL,
  `played_matches` INT DEFAULT 0,
  `wins` INT DEFAULT 0,
  `draws` INT DEFAULT 0,
  `losses` INT DEFAULT 0,
  `goals_for` INT DEFAULT 0,
  `goals_against` INT DEFAULT 0,
  `points` INT DEFAULT 0,
  `current_position` INT DEFAULT 0,
  FOREIGN KEY (`team_id`) REFERENCES `team_info`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`league_id`) REFERENCES `leagues`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `team_league_stats` (`league_id`, `season_year`, `played_matches`, `wins`, `draws`, `losses`, `goals_for`, `goals_against`, `points`, `current_position`) VALUES
(1, 2024, 10, 6, 2, 2, 18, 9, 20, 3),
(2, 2024, 2, 1, 0, 1, 3, 2, 3, 2);



CREATE TABLE `matches` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `home_team_name` VARCHAR(100) NOT NULL, 
  `away_team_name` VARCHAR(100) NOT NULL, 
  `match_date` DATETIME NOT NULL,
  `venue` VARCHAR(255) NOT NULL,
  `league_id` INT,
  `home_score` INT,
  `away_score` INT,
  `status` ENUM('rejalashtirilgan', 'oʻynalgan', 'bekor qilingan') NOT NULL DEFAULT 'rejalashtirilgan',
  `ticket_price` DECIMAL(10, 2) DEFAULT 0.00,
  `our_team_is_home` BOOLEAN DEFAULT TRUE, 
  FOREIGN KEY (`league_id`) REFERENCES `leagues`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


INSERT INTO `matches` (`home_team_name`, `away_team_name`, `match_date`, `venue`, `league_id`, `home_score`, `away_score`, `status`, `ticket_price`, `our_team_is_home`) VALUES
('FC Jasorat', 'Paxtakor FK', '2024-06-15 19:00:00', 'Jasorat Stadium, Toshkent', 1, 2, 1, 'oʻynalgan', 50000.00, TRUE),
('Navbahor FK', 'FC Jasorat', '2024-06-22 18:00:00', 'Navbahor Stadium, Namangan', 1, NULL, NULL, 'rejalashtirilgan', 40000.00, FALSE),
('FC Jasorat', 'Al-Hilal SFC', '2025-07-10 20:00:00', 'Milliy Stadium, Toshkent', 2, NULL, NULL, 'rejalashtirilgan', 150000.00, TRUE);

CREATE TABLE `ticket_applications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `match_id` INT NOT NULL,
  `user_name` VARCHAR(100) NOT NULL,
  `user_email` VARCHAR(100) NOT NULL,
  `user_phone` VARCHAR(20) NOT NULL,
  `quantity` INT NOT NULL DEFAULT 1,
  `status` ENUM('kutilmoqda', 'tasdiqlangan', 'rad etilgan') NOT NULL DEFAULT 'kutilmoqda',
  `application_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`match_id`) REFERENCES `matches`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `training_sessions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(150) NOT NULL,
  `description` TEXT,
  `price_monthly` DECIMAL(10, 2) NOT NULL,
  `schedule_details` VARCHAR(255),
  `age_group` VARCHAR(50) 
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


INSERT INTO `training_sessions` (`name`, `description`, `price_monthly`, `schedule_details`, `age_group`) VALUES
('Bolalar uchun futbol maktabi (7-10 yosh)', 'Yosh futbolchilarni tayyorlash, asosiy koʻnikmalarni oʻrgatish va oʻyinga mehr uygʻotish.', 300000.00, 'Haftada 3 marta: Seshanba, Payshanba, Shanba (15:00 - 17:00)', '7-10 yosh'),
('Oʻsmirlar guruhi (11-14 yosh)', 'Texnik va taktik mahoratni oshirish, jismoniy tayyorgarlikni mustahkamlash.', 400000.00, 'Haftada 4 marta: Dushanba, Chorshanba, Juma (16:00 - 18:00), Yakshanba (10:00 - 12:00)', '11-14 yosh'),
('Kattalar uchun havaskorlar guruhi', 'Futbol oʻynashni yaxshi koʻradigan kattalar uchun sogʻlom turmush tarzi va qiziqarli mashgʻulotlar.', 250000.00, 'Haftada 2 marta: Seshanba, Payshanba (19:00 - 21:00)', '18+ yosh');

CREATE TABLE `training_applications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `session_id` INT NOT NULL,
  `applicant_name` VARCHAR(100) NOT NULL, 
  `applicant_age` INT,
  `parent_name` VARCHAR(100), 
  `user_email` VARCHAR(100) NOT NULL,
  `user_phone` VARCHAR(20) NOT NULL,
  `status` ENUM('kutilmoqda', 'tasdiqlangan', 'rad etilgan') NOT NULL DEFAULT 'kutilmoqda',
  `application_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`session_id`) REFERENCES `training_sessions`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;