
document.addEventListener('DOMContentLoaded', function() {
    

 
    const currentLocation = window.location.href;
    const navLinks = document.querySelectorAll('nav ul li a');
    navLinks.forEach(link => {
        if (link.href === currentLocation) {
            link.classList.add('active');
        }
    });

    console.log("Bunyodkor sayti uchun JavaScript yuklandi!");

    
    const ticketForm = document.getElementById('ticketApplicationForm');
    if (ticketForm) {
        ticketForm.addEventListener('submit', function(event) {
            const userName = document.getElementById('userName');
            const userPhone = document.getElementById('userPhone');
            let isValid = true;

            if (userName && userName.value.trim() === '') {
                alert('Iltimos, ismingizni kiriting.');
                isValid = false;
            }
            if (userPhone && userPhone.value.trim() === '') {
                alert('Iltimos, telefon raqamingizni kiriting.');
                isValid = false;
            }
           

            if (!isValid) {
                event.preventDefault();
            }
        });
    }

    const trainingForm = document.getElementById('trainingApplicationForm');
    if (trainingForm) {
        trainingForm.addEventListener('submit', function(event) {
            const childFullName = document.getElementById('childFullName');
            const childBirthDate = document.getElementById('childBirthDate');
            const parentFullName = document.getElementById('parentFullName');
            const parentPhone = document.getElementById('parentPhone');
            let isValid = true;

            if (childFullName && childFullName.value.trim() === '') {
                alert("Iltimos, farzandingizning F.I.Sh. ni kiriting.");
                isValid = false;
            }
            if (childBirthDate && childBirthDate.value.trim() === '') {
                alert("Iltimos, farzandingizning tug'ilgan sanasini kiriting.");
                isValid = false;
            }
            if (parentFullName && parentFullName.value.trim() === '') {
                alert("Iltimos, ota-ona F.I.Sh. ni kiriting.");
                isValid = false;
            }
            if (parentPhone && parentPhone.value.trim() === '') {
                alert("Iltimos, telefon raqamingizni kiriting.");
                isValid = false;
            }

            if (!isValid) {
                event.preventDefault();
            }
        });
    }

});

function confirmAction(message) {
    return confirm(message || "Haqiqatan ham bu amalni bajarmoqchimisiz?");
}