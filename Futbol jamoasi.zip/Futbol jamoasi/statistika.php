<?php
require_once 'config.php';
$conn = db_connect();
$page_title = "Statistika va O'yinlar";

$team_id_result = mysqli_query($conn, "SELECT id FROM team_info LIMIT 1");
$our_team_id = ($team_id_result && mysqli_num_rows($team_id_result) > 0) ? mysqli_fetch_assoc($team_id_result)['id'] : 1; 
$team_name_result = mysqli_query($conn, "SELECT name FROM team_info LIMIT 1");
$our_team_name = ($team_name_result && mysqli_num_rows($team_name_result) > 0) ? mysqli_fetch_assoc($team_name_result)['name'] : 'FC Jasorat';



if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_ticket_application'])) {
    $match_id = mysqli_real_escape_string($conn, $_POST['match_id']);
    $user_name = mysqli_real_escape_string($conn, $_POST['user_name']);
    $user_email = mysqli_real_escape_string($conn, $_POST['user_email']);
    $user_phone = mysqli_real_escape_string($conn, $_POST['user_phone']);
    $quantity = intval($_POST['quantity']);

    if (empty($user_name) || empty($user_email) || empty($user_phone) || $quantity <= 0) {
        $_SESSION['message'] = "Iltimos, barcha maydonlarni to'g'ri to'ldiring.";
        $_SESSION['message_type'] = "error";
    } elseif (!filter_var($user_email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['message'] = "Noto'g'ri email format.";
        $_SESSION['message_type'] = "error";
    } else {
        $insert_sql = "INSERT INTO ticket_applications (match_id, user_name, user_email, user_phone, quantity) 
                       VALUES ('$match_id', '$user_name', '$user_email', '$user_phone', $quantity)";
        if (mysqli_query($conn, $insert_sql)) {
            $_SESSION['message'] = "Arizangiz muvaffaqiyatli yuborildi! Tez orada siz bilan bog'lanamiz.";
            $_SESSION['message_type'] = "success";
        } else {
            $_SESSION['message'] = "Xatolik yuz berdi: " . mysqli_error($conn);
            $_SESSION['message_type'] = "error";
        }
    }
    
    header("Location: statistika.php#upcoming-matches");
    exit;
}



$current_year = date("Y");
$stats_sql = "SELECT l.name AS league_name, tls.* 
              FROM team_league_stats tls
              JOIN leagues l ON tls.league_id = l.id
              WHERE tls.team_id = $our_team_id AND tls.season_year = '$current_year'";
$stats_result = mysqli_query($conn, $stats_sql);
$league_stats = [];
if ($stats_result) {
    while ($row = mysqli_fetch_assoc($stats_result)) {
        $league_stats[] = $row;
    }
}


$played_matches_sql = "SELECT m.*, l.name as league_name 
                       FROM matches m 
                       LEFT JOIN leagues l ON m.league_id = l.id
                       WHERE m.status = 'oʻynalgan' 
                       AND (m.home_team_name = '$our_team_name' OR m.away_team_name = '$our_team_name')
                       ORDER BY m.match_date DESC LIMIT 10"; 
$played_matches_result = mysqli_query($conn, $played_matches_sql);
$played_matches = [];
if ($played_matches_result) {
    while ($row = mysqli_fetch_assoc($played_matches_result)) {
        $played_matches[] = $row;
    }
}


$upcoming_matches_sql = "SELECT m.*, l.name as league_name 
                         FROM matches m
                         LEFT JOIN leagues l ON m.league_id = l.id
                         WHERE m.status = 'rejalashtirilgan' 
                         AND (m.home_team_name = '$our_team_name' OR m.away_team_name = '$our_team_name')
                         AND m.match_date >= NOW()
                         ORDER BY m.match_date ASC";
$upcoming_matches_result = mysqli_query($conn, $upcoming_matches_sql);
$upcoming_matches = [];
if ($upcoming_matches_result) {
    while ($row = mysqli_fetch_assoc($upcoming_matches_result)) {
        $upcoming_matches[] = $row;
    }
}


include 'includes/_header.php';
?>

<h2 class="page-title">Jamoa Statistikasi va O'yinlar</h2>

<div class="card">
    <h3>Joriy Mavsum Statistikasi (<?php echo $current_year; ?>)</h3>
    <?php if (!empty($league_stats)): ?>
        <table class="styled-table">
            <thead>
                <tr>
                    <th>Chempionat</th>
                    <th>O'rin</th>
                    <th>O'yin</th>
                    <th>G'alaba</th>
                    <th>Durang</th>
                    <th>Mag'lubiyat</th>
                    <th>Gollar (Urilgan/O'tkazilgan)</th>
                    <th>Ochko</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($league_stats as $stat): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($stat['league_name']); ?></td>
                        <td><?php echo htmlspecialchars($stat['current_position']); ?></td>
                        <td><?php echo htmlspecialchars($stat['played_matches']); ?></td>
                        <td><?php echo htmlspecialchars($stat['wins']); ?></td>
                        <td><?php echo htmlspecialchars($stat['draws']); ?></td>
                        <td><?php echo htmlspecialchars($stat['losses']); ?></td>
                        <td><?php echo htmlspecialchars($stat['goals_for']); ?> : <?php echo htmlspecialchars($stat['goals_against']); ?></td>
                        <td><?php echo htmlspecialchars($stat['points']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Bu mavsum uchun statistika hali mavjud emas.</p>
    <?php endif; ?>
</div>

<div class="card">
    <h3>Oxirgi O'yin Natijalari</h3>
    <?php if (!empty($played_matches)): ?>
        <?php foreach ($played_matches as $match): ?>
            <div class="match-card">
                <h4><?php echo htmlspecialchars($match['league_name'] ?? 'Oʻrtoqlik uchrashuvi'); ?></h4>
                <p class="match-teams">
                    <?php echo htmlspecialchars($match['home_team_name']); ?> 
                    <span class="match-score"><?php echo htmlspecialchars($match['home_score'] ?? '-'); ?> : <?php echo htmlspecialchars($match['away_score'] ?? '-'); ?></span> 
                    <?php echo htmlspecialchars($match['away_team_name']); ?>
                </p>
                <div class="match-info">
                    <p><strong>Sana:</strong> <?php echo format_date_uz($match['match_date']); ?></p>
                    <p><strong>Manzil:</strong> <?php echo htmlspecialchars($match['venue']); ?></p>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>O'ynalgan o'yinlar haqida ma'lumot yo'q.</p>
    <?php endif; ?>
</div>

<div class="card" id="upcoming-matches">
    <h3>Kelgusi O'yinlar va Chiptalar</h3>
    <?php if (!empty($upcoming_matches)): ?>
        <?php foreach ($upcoming_matches as $match): ?>
            <div class="match-card">
                <h4><?php echo htmlspecialchars($match['league_name'] ?? 'Oʻrtoqlik uchrashuvi'); ?></h4>
                <p class="match-teams">
                    <?php echo htmlspecialchars($match['home_team_name']); ?> 
                    <span>vs</span> 
                    <?php echo htmlspecialchars($match['away_team_name']); ?>
                </p>
                <div class="match-info">
                    <p><strong>Sana:</strong> <?php echo format_date_uz($match['match_date']); ?></p>
                    <p><strong>Manzil:</strong> <?php echo htmlspecialchars($match['venue']); ?></p>
                </div>
                <?php if ($match['ticket_price'] > 0): ?>
                <div class="ticket-info">
                    <p><strong>Chipta narxi:</strong> <?php echo number_format($match['ticket_price'], 0, '.', ' '); ?> so'm</p>
                    <button class="btn" onclick="toggleTicketForm('form_<?php echo $match['id']; ?>')">Chiptaga Ariza Berish</button>
                    <form id="form_<?php echo $match['id']; ?>" method="POST" action="statistika.php" style="display:none; margin-top:15px; padding:15px; background-color:#f9f9f9; border-radius:5px;">
                        <input type="hidden" name="match_id" value="<?php echo $match['id']; ?>">
                        <h4>Chiptaga Ariza (<?php echo htmlspecialchars($match['home_team_name']); ?> vs <?php echo htmlspecialchars($match['away_team_name']); ?>)</h4>
                        <div class="form-group">
                            <label for="user_name_<?php echo $match['id']; ?>">To'liq ismingiz:</label>
                            <input type="text" id="user_name_<?php echo $match['id']; ?>" name="user_name" required>
                        </div>
                        <div class="form-group">
                            <label for="user_email_<?php echo $match['id']; ?>">Email manzilingiz:</label>
                            <input type="email" id="user_email_<?php echo $match['id']; ?>" name="user_email" required>
                        </div>
                        <div class="form-group">
                            <label for="user_phone_<?php echo $match['id']; ?>">Telefon raqamingiz:</label>
                            <input type="tel" id="user_phone_<?php echo $match['id']; ?>" name="user_phone" required>
                        </div>
                        <div class="form-group">
                            <label for="quantity_<?php echo $match['id']; ?>">Chiptalar soni:</label>
                            <input type="number" id="quantity_<?php echo $match['id']; ?>" name="quantity" min="1" value="1" required>
                        </div>
                        <button type="submit" name="submit_ticket_application" class="btn">Ariza Yuborish</button>
                    </form>
                </div>
                <?php else: ?>
                <p><em>Bu o'yin uchun chiptalar sotuvda emas yoki bepul.</em></p>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>Hozircha rejalashtirilgan o'yinlar yo'q.</p>
    <?php endif; ?>
</div>

<script>
function toggleTicketForm(formId) {
    var form = document.getElementById(formId);
    if (form.style.display === "none" || form.style.display === "") {
        form.style.display = "block";
    } else {
        form.style.display = "none";
    }
}
</script>

<?php
mysqli_close($conn);
include 'includes/_footer.php';
?>