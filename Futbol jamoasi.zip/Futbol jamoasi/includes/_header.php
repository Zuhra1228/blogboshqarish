<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start(); 
}
$current_page = basename($_SERVER['PHP_SELF']);


$site_title = "Futbol Jamoasi";
if (isset($conn) && function_exists('db_connect')) {
    $team_info_query = mysqli_query($conn, "SELECT name FROM team_info LIMIT 1");
    if ($team_info_query && mysqli_num_rows($team_info_query) > 0) {
        $team_row = mysqli_fetch_assoc($team_info_query);
        $site_title = htmlspecialchars($team_row['name']);
    }
}
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? $site_title; ?></title>
    <link rel="stylesheet" href="css/style.css">
   
    <?php if (isset($extra_css)): ?>
        <?php foreach ($extra_css as $css_file): ?>
            <link rel="stylesheet" href="<?php echo $css_file; ?>">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body>
    <header>
        <div class="container">
            <h1><a href="index.php"><?php echo $site_title; ?> <span class="logo-highlight">Rasmiy Sayti</span></a></h1>
            <nav>
                <ul>
                    <li><a href="jamoa_haqida.php" class="<?php echo ($current_page == 'jamoa_haqida.php') ? 'active' : ''; ?>">Jamoa Haqida</a></li>
                    <li><a href="statistika.php" class="<?php echo ($current_page == 'statistika.php') ? 'active' : ''; ?>">Statistika va O'yinlar</a></li>
                    <li><a href="mashgulotlar.php" class="<?php echo ($current_page == 'mashgulotlar.php') ? 'active' : ''; ?>">Mashg'ulotlarga Yozilish</a></li>
                    <li><a href="admin/login.php">Admin Kirish</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <main>
        <div class="container">
            <?php
     
            if (function_exists('display_message')) {
                display_message();
            }
            ?>