</div> 
    </main>
    <footer>
        <div class="container">
            <p>&copy; <?php echo date("Y"); ?> <?php echo $site_title ?? "Futbol Jamoasi"; ?>. Barcha huquqlar himoyalangan.</p>
        </div>
    </footer>
    
    <?php if (isset($extra_js)): ?>
        <?php foreach ($extra_js as $js_file): ?>
            <script src="<?php echo $js_file; ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>