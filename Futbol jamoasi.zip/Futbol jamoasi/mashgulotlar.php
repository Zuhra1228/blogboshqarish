<?php
require_once 'config.php';
$conn = db_connect();
$page_title = "Mashg'ulotlarga Yozilish";


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_training_application'])) {
    $session_id = mysqli_real_escape_string($conn, $_POST['session_id']);
    $applicant_name = mysqli_real_escape_string($conn, $_POST['applicant_name']);
    $applicant_age = isset($_POST['applicant_age']) ? intval($_POST['applicant_age']) : NULL;
    $parent_name = isset($_POST['parent_name']) ? mysqli_real_escape_string($conn, $_POST['parent_name']) : NULL;
    $user_email = mysqli_real_escape_string($conn, $_POST['user_email']);
    $user_phone = mysqli_real_escape_string($conn, $_POST['user_phone']);

    if (empty($applicant_name) || empty($user_email) || empty($user_phone) || empty($session_id)) {
        $_SESSION['message'] = "Iltimos, barcha zarur maydonlarni to'ldiring.";
        $_SESSION['message_type'] = "error";
    } elseif (!filter_var($user_email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['message'] = "Noto'g'ri email format.";
        $_SESSION['message_type'] = "error";
    } else {
        $age_val = $applicant_age ? $applicant_age : "NULL";
        $parent_val = $parent_name ? "'$parent_name'" : "NULL";

        $insert_sql = "INSERT INTO training_applications (session_id, applicant_name, applicant_age, parent_name, user_email, user_phone) 
                       VALUES ('$session_id', '$applicant_name', $age_val, $parent_val, '$user_email', '$user_phone')";
        if (mysqli_query($conn, $insert_sql)) {
            $_SESSION['message'] = "Arizangiz muvaffaqiyatli yuborildi! Tez orada siz bilan bog'lanamiz.";
            $_SESSION['message_type'] = "success";
        } else {
            $_SESSION['message'] = "Xatolik yuz berdi: " . mysqli_error($conn);
            $_SESSION['message_type'] = "error";
        }
    }
    header("Location: mashgulotlar.php");
    exit;
}



$sessions_sql = "SELECT * FROM training_sessions ORDER BY age_group, name";
$sessions_result = mysqli_query($conn, $sessions_sql);
$training_sessions = [];
if ($sessions_result) {
    while ($row = mysqli_fetch_assoc($sessions_result)) {
        $training_sessions[] = $row;
    }
}

include 'includes/_header.php';
?>

<h2 class="page-title">Klub Mashg'ulotlariga Yozilish</h2>

<p>Bizning klubimiz turli yoshdagi va saviyadagi futbol ishqibozlari uchun mashg'ulotlar taklif etadi. Quyida mavjud guruhlar va ularga yozilish uchun ma'lumotlar keltirilgan.</p>

<?php if (!empty($training_sessions)): ?>
    <div class="training-grid">
        <?php foreach ($training_sessions as $session): ?>
            <div class="training-card">
                <h3><?php echo htmlspecialchars($session['name']); ?></h3>
                <?php if (!empty($session['age_group'])): ?>
                    <p><strong>Yosh guruhi:</strong> <?php echo htmlspecialchars($session['age_group']); ?></p>
                <?php endif; ?>
                <?php if (!empty($session['description'])): ?>
                    <p><?php echo nl2br(htmlspecialchars($session['description'])); ?></p>
                <?php endif; ?>
                <?php if (!empty($session['schedule_details'])): ?>
                    <p><strong>Dars jadvali:</strong> <?php echo htmlspecialchars($session['schedule_details']); ?></p>
                <?php endif; ?>
                <p class="price"><strong>Oylik to'lov:</strong> <?php echo number_format($session['price_monthly'], 0, '.', ' '); ?> so'm</p>
                <button class="btn" onclick="showApplicationForm(<?php echo $session['id']; ?>, '<?php echo htmlspecialchars(addslashes($session['name'])); ?>')">Ushbu guruhga yozilish</button>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="card" id="training-application-form-container" style="display:none; margin-top:30px;">
        <h3 id="form-title">Mashg'ulotga Yozilish Arizasi</h3>
        <form method="POST" action="mashgulotlar.php">
            <input type="hidden" name="session_id" id="session_id_field">
            <div class="form-group">
                <label for="applicant_name">Arizachi (yoki bola)ning to'liq ismi:</label>
                <input type="text" id="applicant_name" name="applicant_name" required>
            </div>
            <div class="form-group">
                <label for="applicant_age">Arizachining yoshi (agar bola uchun bo'lsa):</label>
                <input type="number" id="applicant_age" name="applicant_age" min="5" max="60">
            </div>
            <div class="form-group">
                <label for="parent_name">Ota-ona ismi (agar bola uchun bo'lsa):</label>
                <input type="text" id="parent_name" name="parent_name">
            </div>
            <div class="form-group">
                <label for="user_email">Email manzilingiz:</label>
                <input type="email" id="user_email" name="user_email" required>
            </div>
            <div class="form-group">
                <label for="user_phone">Telefon raqamingiz:</label>
                <input type="tel" id="user_phone" name="user_phone" required placeholder="+998 XX XXX XX XX">
            </div>
            <button type="submit" name="submit_training_application" class="btn">Ariza Yuborish</button>
        </form>
    </div>

<script>
function showApplicationForm(sessionId, sessionName) {
    document.getElementById('session_id_field').value = sessionId;
    document.getElementById('form-title').innerText = '"' + sessionName + '" mashg\'ulotiga yozilish arizasi';
    document.getElementById('training-application-form-container').style.display = 'block';
    document.getElementById('applicant_name').focus();
    // Scroll to the form
    document.getElementById('training-application-form-container').scrollIntoView({ behavior: 'smooth' });
}
</script>

<?php else: ?>
    <p>Hozircha mashg'ulotlar haqida ma'lumot yo'q. Tez orada yangilanadi.</p>
<?php endif; ?>

<?php
mysqli_close($conn);
include 'includes/_footer.php';
?>