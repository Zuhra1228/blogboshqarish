<?php

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root'); 
define('DB_PASSWORD', ''); 
define('DB_NAME', 'jamoasi_db');

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

function db_connect() {
    $connection = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
    if (!$connection) {
        die("Xatolik: Ma'lumotlar bazasiga ulanib bo'lmadi. " . mysqli_connect_error());
    }
    mysqli_set_charset($connection, "utf8mb4");
    return $connection;
}

function display_message() {
    if (isset($_SESSION['message'])) {
        echo '<div class="message ' . ($_SESSION['message_type'] ?? 'info') . '">' . htmlspecialchars($_SESSION['message']) . '</div>';
        unset($_SESSION['message']);
        unset($_SESSION['message_type']);
    }
}

function is_admin_logged_in() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

function ensure_admin_logged_in() {
    if (!is_admin_logged_in()) {
        $_SESSION['message'] = "Bu sahifaga kirish uchun avval tizimga kirishingiz kerak.";
        $_SESSION['message_type'] = "error";
        header("Location: login.php");
        exit;
    }
}

function format_date_uz($datetime_str) {
    if (empty($datetime_str)) return '';
    $timestamp = strtotime($datetime_str);
    $oylar = [
        1 => 'Yanvar', 2 => 'Fevral', 3 => 'Mart', 4 => 'Aprel',
        5 => 'May', 6 => 'Iyun', 7 => 'Iyul', 8 => 'Avgust',
        9 => 'Sentyabr', 10 => 'Oktyabr', 11 => 'Noyabr', 12 => 'Dekabr'
    ];
    $kun = date('d', $timestamp);
    $oy = $oylar[date('n', $timestamp)];
    $yil = date('Y', $timestamp);
    $soat = date('H:i', $timestamp);
    return "$kun $oy, $yil, $soat";
}
function format_date_only_uz($date_str) {
    if (empty($date_str)) return '';
    $timestamp = strtotime($date_str);
     $oylar = [
        1 => 'Yanvar', 2 => 'Fevral', 3 => 'Mart', 4 => 'Aprel',
        5 => 'May', 6 => 'Iyun', 7 => 'Iyul', 8 => 'Avgust',
        9 => 'Sentyabr', 10 => 'Oktyabr', 11 => 'Noyabr', 12 => 'Dekabr'
    ];
    $kun = date('d', $timestamp);
    $oy = $oylar[date('n', $timestamp)];
    $yil = date('Y', $timestamp);
    return "$kun $oy, $yil";
}

?>