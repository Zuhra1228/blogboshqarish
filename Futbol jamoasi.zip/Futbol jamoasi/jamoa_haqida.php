<?php
require_once 'config.php';
$conn = db_connect();

$page_title = "Jamoa Haqida";


$team_query = mysqli_query($conn, "SELECT * FROM team_info LIMIT 1");
$team = mysqli_fetch_assoc($team_query);
if (!$team) {
    
    $team = [
        'name' => 'FC Jasorat (Namunaviy)',
        'foundation_date' => '2000-01-01',
        'country' => 'Oʻzbekiston',
        'owner' => 'Nomaʼlum',
        'description' => 'Jamoa haqida maʼlumot topilmadi. Iltimos, admin panelidan maʼlumotlarni kiriting.',
        'logo_url' => 'images/logo_placeholder.png'
    ];
}


$players_query = mysqli_query($conn, "SELECT * FROM players ORDER BY position, full_name");
$players = [];
if ($players_query) {
    while ($row = mysqli_fetch_assoc($players_query)) {
        $players[] = $row;
    }
}


$leagues_query_sql = "SELECT l.name 
                      FROM leagues l
                      JOIN team_league_stats tls ON l.id = tls.league_id
                      WHERE tls.team_id = (SELECT id FROM team_info LIMIT 1)
                      GROUP BY l.name";
$leagues_query = mysqli_query($conn, $leagues_query_sql);
$leagues = [];
if ($leagues_query) {
    while ($row = mysqli_fetch_assoc($leagues_query)) {
        $leagues[] = $row['name'];
    }
}


include 'includes/_header.php';
?>

<h2 class="page-title">Jamoa Haqida Ma'lumot</h2>

<div class="card team-overview">
    <div style="display: flex; align-items: flex-start; gap: 20px;">
        <?php if (!empty($team['logo_url']) && file_exists($team['logo_url'])): ?>
            <img src="<?php echo htmlspecialchars($team['logo_url']); ?>" alt="<?php echo htmlspecialchars($team['name']); ?> Logotipi" style="width: 150px; height: auto; border-radius: 8px; border: 1px solid #ddd;">
        <?php elseif(!empty($team['logo_url'])): ?>
             <img src="images/logo_placeholder.png" alt="Standart Logotip" style="width: 150px; height: auto; border-radius: 8px; border: 1px solid #ddd;">
        <?php endif; ?>
        <div>
            <h3><?php echo htmlspecialchars($team['name']); ?></h3>
            <p><strong>Tashkil topgan sana:</strong> <?php echo format_date_only_uz($team['foundation_date']); ?></p>
            <p><strong>Mamlakat:</strong> <?php echo htmlspecialchars($team['country']); ?></p>
            <p><strong>Jamoa egasi:</strong> <?php echo htmlspecialchars($team['owner']); ?></p>
            <?php if (!empty($leagues)): ?>
            <p><strong>Ishtirok etadigan chempionatlar:</strong> <?php echo implode(', ', array_map('htmlspecialchars', $leagues)); ?></p>
            <?php endif; ?>
        </div>
    </div>
    <?php if (!empty($team['description'])): ?>
    <div style="margin-top: 20px;">
        <h4>Jamoa Tavsifi:</h4>
        <p><?php echo nl2br(htmlspecialchars($team['description'])); ?></p>
    </div>
    <?php endif; ?>
</div>


<h3 class="page-title" style="margin-top: 30px;">Jamoa Tarkibi</h3>
<?php if (!empty($players)): ?>
    <div class="players-grid">
        <?php foreach ($players as $player): ?>
            <div class="player-card">
                <?php
                $player_image = 'images/player_placeholder.png'; // Standart rasm
                if (!empty($player['image_url']) && file_exists($player['image_url'])) {
                    $player_image = $player['image_url'];
                }
                ?>
                <img src="<?php echo htmlspecialchars($player_image); ?>" alt="<?php echo htmlspecialchars($player['full_name']); ?>">
                <h4><?php echo htmlspecialchars($player['full_name']); ?></h4>
                <p><strong>Pozitsiyasi:</strong> <?php echo htmlspecialchars($player['position']); ?></p>
                <p><strong>Raqami:</strong> <?php echo htmlspecialchars($player['jersey_number']); ?></p>
                <p><strong>Tug'ilgan sana:</strong> <?php echo format_date_only_uz($player['date_of_birth']); ?></p>
                <p><strong>Millati:</strong> <?php echo htmlspecialchars($player['nationality']); ?></p>
            </div>
        <?php endforeach; ?>
    </div>
<?php else: ?>
    <p>Hozircha jamoa tarkibi haqida ma'lumot yo'q.</p>
<?php endif; ?>

<?php
mysqli_close($conn);
include 'includes/_footer.php';
?>