document.addEventListener('DOMContentLoaded', function() {
 
    let currentUser = null;
    let currentChat = null;
    let contacts = [];
    let personalChats = [];
    let groupChats = [];
    let stickers = [
        'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f600.png',
        'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f601.png',
        'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f602.png',
        'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f603.png',
        'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f604.png',
        'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f605.png',
        'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f606.png',
        'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f609.png',
        'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f60a.png',
        'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f60b.png',
        'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f60e.png',
        'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f60d.png',
        'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f618.png',
        'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f970.png',
        'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f917.png'
    ];


    const isLoginPage = document.querySelector('.login-container') !== null;

    if (isLoginPage) {
        initLoginPage();
    } else {
        initChatPage();
    }

   
    function initLoginPage() {
        const loginToggle = document.getElementById('login-toggle');
        const registerToggle = document.getElementById('register-toggle');
        const loginForm = document.getElementById('login-form');
        const registerForm = document.getElementById('register-form');

        loginToggle.addEventListener('click', function() {
            loginToggle.classList.add('active');
            registerToggle.classList.remove('active');
            loginForm.classList.add('active');
            registerForm.classList.remove('active');
        });

        registerToggle.addEventListener('click', function() {
            registerToggle.classList.add('active');
            loginToggle.classList.remove('active');
            registerForm.classList.add('active');
            loginForm.classList.remove('active');
        });

  
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const username = document.getElementById('login-username').value;
            const password = document.getElementById('login-password').value;

            
            fetch('server.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'login',
                    username: username,
                    password: password
                }),
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                  
                    localStorage.setItem('user', JSON.stringify(data.user));
                    window.location.href = 'main.html';
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Xatolik yuz berdi. Iltimos, qaytadan urinib ko\'ring.');
            });
        });

        
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const fullname = document.getElementById('register-fullname').value;
            const username = document.getElementById('register-username').value;
            const password = document.getElementById('register-password').value;
            const confirmPassword = document.getElementById('register-confirm-password').value;
            const profileImage = document.getElementById('profile-image').files[0];

            if (password !== confirmPassword) {
                alert('Parollar mos kelmadi!');
                return;
            }

          
            const formData = new FormData();
            formData.append('action', 'register');
            formData.append('fullname', fullname);
            formData.append('username', username);
            formData.append('password', password);
            if (profileImage) {
                formData.append('profile_image', profileImage);
            }

         
            fetch('server.php', {
                method: 'POST',
                body: formData,
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Ro\'yxatdan muvaffaqiyatli o\'tdingiz! Endi tizimga kirishingiz mumkin.');
                    
                    loginToggle.click();
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Xatolik yuz berdi. Iltimos, qaytadan urinib ko\'ring.');
            });
        });
    }


    function initChatPage() {
        
        const userJson = localStorage.getItem('user');
        if (!userJson) {
            window.location.href = 'index.html';
            return;
        }
        
        currentUser = JSON.parse(userJson);
        
    
        document.getElementById('current-user-name').textContent = currentUser.fullname;
        if (currentUser.profile_image) {
            document.getElementById('current-user-avatar').src = currentUser.profile_image;
        }
        
     
        const tabs = document.querySelectorAll('.tab');
        tabs.forEach(tab => {
            tab.addEventListener('click', function() {
                const tabName = this.getAttribute('data-tab');
                
              
                document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
                this.classList.add('active');
                
              
                document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
                document.getElementById(tabName + '-chats').classList.add('active');
            });
        });
        
       
        const modalTabs = document.querySelectorAll('[data-modal-tab]');
        modalTabs.forEach(tab => {
            tab.addEventListener('click', function() {
                const tabName = this.getAttribute('data-modal-tab');
                
               
                document.querySelectorAll('[data-modal-tab]').forEach(t => t.classList.remove('active'));
                this.classList.add('active');
                
             
                document.querySelectorAll('.modal .tab-content').forEach(content => content.classList.remove('active'));
                document.getElementById(tabName + '-tab').classList.add('active');
            });
        });
        
      
        const stickerBtn = document.getElementById('sticker-btn');
        const stickerPanel = document.getElementById('sticker-panel');
        
        stickerBtn.addEventListener('click', function() {
            if (stickerPanel.style.display === 'block') {
                stickerPanel.style.display = 'none';
            } else {
                stickerPanel.style.display = 'block';
                renderStickers();
            }
        });
        
        
        function renderStickers() {
            const stickerGrid = document.querySelector('.sticker-grid');
            stickerGrid.innerHTML = '';
            
            stickers.forEach(stickerUrl => {
                const stickerImg = document.createElement('img');
                stickerImg.src = stickerUrl;
                stickerImg.classList.add('sticker');
                stickerImg.addEventListener('click', function() {
                    sendSticker(stickerUrl);
                    stickerPanel.style.display = 'none';
                });
                
                stickerGrid.appendChild(stickerImg);
            });
        }
        
       
        function sendSticker(stickerUrl) {
            if (!currentChat) return;
            
            const messageData = {
                action: 'send_message',
                chat_id: currentChat.id,
                chat_type: currentChat.type,
                message_type: 'sticker',
                content: stickerUrl,
                sender_id: currentUser.id
            };
            
            fetch('server.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(messageData),
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    addMessageToChat(data.message);
                    loadChats(); 
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }
        
      
        const sendBtn = document.getElementById('send-btn');
        const messageText = document.getElementById('message-text');
        
        sendBtn.addEventListener('click', sendMessage);
        messageText.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });
        
        function sendMessage() {
            if (!currentChat || !messageText.value.trim()) return;
            
            const messageData = {
                action: 'send_message',
                chat_id: currentChat.id,
                chat_type: currentChat.type,
                message_type: 'text',
                content: messageText.value.trim(),
                sender_id: currentUser.id
            };
            
            fetch('server.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(messageData),
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    messageText.value = '';
                    addMessageToChat(data.message);
                    loadChats(); 
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }
        
      
        function addMessageToChat(message) {
            const messagesContainer = document.getElementById('messages-container');
            const messageDiv = document.createElement('div');
            messageDiv.classList.add('message');
            
            if (message.sender_id === currentUser.id) {
                messageDiv.classList.add('message-outgoing');
            } else {
                messageDiv.classList.add('message-incoming');
            }
            
            if (message.message_type === 'text') {
                messageDiv.innerHTML = `
                    <div class="message-text">${message.content}</div>
                    <div class="message-time">${formatTime(message.timestamp)}</div>
                `;
            } else if (message.message_type === 'sticker') {
                messageDiv.innerHTML = `
                    <img src="${message.content}" class="message-sticker" alt="Sticker">
                    <div class="message-time">${formatTime(message.timestamp)}</div>
                `;
            }
            
            messagesContainer.appendChild(messageDiv);
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
        
        
        function formatTime(timestamp) {
            const date = new Date(timestamp);
            return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        }
        
       
        function loadChats() {
            fetch('server.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'get_chats',
                    user_id: currentUser.id
                }),
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    personalChats = data.personal_chats;
                    groupChats = data.group_chats;
                    
                    renderPersonalChats();
                    renderGroupChats();
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }
        
       
        function loadContacts() {
            fetch('server.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'get_contacts',
                    user_id: currentUser.id
                }),
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    contacts = data.contacts;
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }
        
       
        function renderPersonalChats() {
            const personalChatsContainer = document.getElementById('personal-chats');
            personalChatsContainer.innerHTML = '';
            
            personalChats.forEach(chat => {
                const chatItem = document.createElement('div');
                chatItem.classList.add('chat-item');
                chatItem.dataset.chatId = chat.id;
                chatItem.dataset.chatType = 'personal';
                
                if (currentChat && currentChat.id === chat.id && currentChat.type === 'personal') {
                    chatItem.classList.add('active');
                }
                
                chatItem.innerHTML = `
                    <img src="${chat.profile_image || 'https://via.placeholder.com/40'}" alt="${chat.name}" class="avatar">
                    <div class="chat-item-info">
                        <div class="chat-item-header">
                            <span class="chat-item-name">${chat.name}</span>
                            <span class="chat-item-time">${chat.last_message ? formatTime(chat.last_message.timestamp) : ''}</span>
                        </div>
                        <div class="chat-item-last-message">${chat.last_message ? (chat.last_message.message_type === 'sticker' ? 'Stiker' : chat.last_message.content) : 'Hali xabar yo\'q'}</div>
                    </div>
                `;
                
                chatItem.addEventListener('click', function() {
                    openChat(chat, 'personal');
                });
                
                personalChatsContainer.appendChild(chatItem);
            });
        }
        
       
        function renderGroupChats() {
            const groupChatsContainer = document.getElementById('group-chats');
            groupChatsContainer.innerHTML = '';
            
            groupChats.forEach(chat => {
                const chatItem = document.createElement('div');
                chatItem.classList.add('chat-item');
                chatItem.dataset.chatId = chat.id;
                chatItem.dataset.chatType = 'group';
                
                if (currentChat && currentChat.id === chat.id && currentChat.type === 'group') {
                    chatItem.classList.add('active');
                }
                
                chatItem.innerHTML = `
                    <img src="${chat.profile_image || 'https://via.placeholder.com/40'}" alt="${chat.name}" class="avatar">
                    <div class="chat-item-info">
                        <div class="chat-item-header">
                            <span class="chat-item-name">${chat.name}</span>
                            <span class="chat-item-time">${chat.last_message ? formatTime(chat.last_message.timestamp) : ''}</span>
                        </div>
                        <div class="chat-item-last-message">${chat.last_message ? (chat.last_message.message_type === 'sticker' ? 'Stiker' : chat.last_message.content) : 'Hali xabar yo\'q'}</div>
                    </div>
                `;
                
                chatItem.addEventListener('click', function() {
                    openChat(chat, 'group');
                });
                
                groupChatsContainer.appendChild(chatItem);
            });
        }
        
       
        function openChat(chat, type) {
            currentChat = { ...chat, type: type };
            
          
            document.querySelectorAll('.chat-item').forEach(item => item.classList.remove('active'));
            document.querySelector(`.chat-item[data-chat-id="${chat.id}"][data-chat-type="${type}"]`).classList.add('active');
            
            
            document.getElementById('chat-name').textContent = chat.name;
            document.getElementById('chat-avatar').src = chat.profile_image || 'https://via.placeholder.com/40';
            
          
            document.getElementById('welcome-screen').style.display = 'none';
            document.getElementById('chat-window').style.display = 'flex';
            
          
            loadMessages(chat.id, type);
        }
        
       
        function loadMessages(chatId, chatType) {
            fetch('server.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'get_messages',
                    chat_id: chatId,
                    chat_type: chatType
                }),
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const messagesContainer = document.getElementById('messages-container');
                    messagesContainer.innerHTML = '';
                    
                    data.messages.forEach(message => {
                        addMessageToChat(message);
                    });
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }
        
       
        const newChatBtn = document.getElementById('new-chat-btn');
        const newChatModal = document.getElementById('new-chat-modal');
        
        newChatBtn.addEventListener('click', function() {
            openModal(newChatModal);
            loadContacts();
            renderContactsForGroup();
        });
        
       
        function renderContactsForGroup() {
            const groupContacts = document.getElementById('group-contacts');
            groupContacts.innerHTML = '';
            
            contacts.forEach(contact => {
                const contactItem = document.createElement('div');
                contactItem.classList.add('contact-item');
                
                contactItem.innerHTML = `
                    <img src="${contact.profile_image || 'https://via.placeholder.com/40'}" alt="${contact.fullname}" class="avatar">
                    <div class="contact-info">
                        <div class="contact-name">${contact.fullname}</div>
                        <div class="contact-username">@${contact.username}</div>
                    </div>
                    <input type="checkbox" class="contact-checkbox" data-contact-id="${contact.id}">
                `;
                
                groupContacts.appendChild(contactItem);
            });
        }
        
       
        const newContactForm = document.getElementById('new-contact-form');
        
        newContactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = document.getElementById('contact-username').value;
            
            fetch('server.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'add_contact',
                    user_id: currentUser.id,
                    contact_username: username
                }),
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Kontakt muvaffaqiyatli qo\'shildi!');
                    closeModal(newChatModal);
                    loadContacts();
                    loadChats();
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });
        
      
        const newGroupForm = document.getElementById('new-group-form');
        
        newGroupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const groupName = document.getElementById('group-name').value;
            const groupImage = document.getElementById('group-image').files[0];
            
           
            const selectedContacts = [];
            document.querySelectorAll('.contact-checkbox:checked').forEach(checkbox => {
                selectedContacts.push(checkbox.dataset.contactId);
            });
            
            if (selectedContacts.length === 0) {
                alert('Kamida bitta a\'zo tanlang!');
                return;
            }
            
            const formData = new FormData();
            formData.append('action', 'create_group');
            formData.append('creator_id', currentUser.id);
            formData.append('group_name', groupName);
            formData.append('members', JSON.stringify(selectedContacts));
            
            if (groupImage) {
                formData.append('group_image', groupImage);
            }
            
            fetch('server.php', {
                method: 'POST',
                body: formData,
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Guruh muvaffaqiyatli yaratildi!');
                    closeModal(newChatModal);
                    loadChats();
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });
        
   
        const chatInfoBtn = document.getElementById('chat-info-btn');
        const groupInfoModal = document.getElementById('group-info-modal');
        
        chatInfoBtn.addEventListener('click', function() {
            if (!currentChat) return;
            
            if (currentChat.type === 'group') {
                openModal(groupInfoModal);
                loadGroupInfo();
            }
        });
        
        
        function loadGroupInfo() {
            fetch('server.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'get_group_info',
                    group_id: currentChat.id
                }),
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('group-info-name').textContent = data.group.name;
                    document.getElementById('group-info-members').textContent = data.members.length;
                    
                    if (data.group.profile_image) {
                        document.getElementById('group-info-image').src = data.group.profile_image;
                    }
                    
                    renderGroupMembers(data.members);
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }
        
        
        function renderGroupMembers(members) {
            const membersList = document.getElementById('group-members-list');
            membersList.innerHTML = '';
            
            members.forEach(member => {
                const memberItem = document.createElement('div');
                memberItem.classList.add('member-item');
                
                memberItem.innerHTML = `
                    <img src="${member.profile_image || 'https://via.placeholder.com/40'}" alt="${member.fullname}" class="avatar">
                    <div class="member-info">
                        <div class="member-name">${member.fullname}</div>
                        <div class="member-username">@${member.username}</div>
                    </div>
                `;
                
                membersList.appendChild(memberItem);
            });
        }
        
        
        const addMemberBtn = document.getElementById('add-member-btn');
        const addMemberModal = document.getElementById('add-member-modal');
        
        addMemberBtn.addEventListener('click', function() {
            openModal(addMemberModal);
            renderContactsForAddMember();
        });
        
        
        function renderContactsForAddMember() {
            fetch('server.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'get_non_members',
                    user_id: currentUser.id,
                    group_id: currentChat.id
                }),
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const contactsList = document.getElementById('add-member-contacts');
                    contactsList.innerHTML = '';
                    
                    data.contacts.forEach(contact => {
                        const contactItem = document.createElement('div');
                        contactItem.classList.add('contact-item');
                        
                        contactItem.innerHTML = `
                            <img src="${contact.profile_image || 'https://via.placeholder.com/40'}" alt="${contact.fullname}" class="avatar">
                            <div class="contact-info">
                                <div class="contact-name">${contact.fullname}</div>
                                <div class="contact-username">@${contact.username}</div>
                            </div>
                            <input type="checkbox" class="contact-checkbox" data-contact-id="${contact.id}">
                        `;
                        
                        contactsList.appendChild(contactItem);
                    });
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }
        
       
        const addSelectedMembersBtn = document.getElementById('add-selected-members');
        
        addSelectedMembersBtn.addEventListener('click', function() {
            
            const selectedContacts = [];
            document.querySelectorAll('#add-member-contacts .contact-checkbox:checked').forEach(checkbox => {
                selectedContacts.push(checkbox.dataset.contactId);
            });
            
            if (selectedContacts.length === 0) {
                alert('Kamida bitta a\'zo tanlang!');
                return;
            }
            
            fetch('server.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'add_members',
                    group_id: currentChat.id,
                    member_ids: selectedContacts
                }),
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('A\'zolar muvaffaqiyatli qo\'shildi!');
                    closeModal(addMemberModal);
                    loadGroupInfo();
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });
        
        
        const leaveGroupBtn = document.getElementById('leave-group-btn');
        
        leaveGroupBtn.addEventListener('click', function() {
            if (confirm('Haqiqatan ham guruhdan chiqmoqchimisiz?')) {
                fetch('server.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        action: 'leave_group',
                        user_id: currentUser.id,
                        group_id: currentChat.id
                    }),
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Guruhdan chiqib ketdingiz!');
                        closeModal(groupInfoModal);
                        loadChats();
                        
                      
                        document.getElementById('welcome-screen').style.display = 'flex';
                        document.getElementById('chat-window').style.display = 'none';
                        currentChat = null;
                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
            }
        });
        
        
        const groupInfoUpload = document.getElementById('group-info-upload');
        
        groupInfoUpload.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (!file) return;
            
            const formData = new FormData();
            formData.append('action', 'update_group_image');
            formData.append('group_id', currentChat.id);
            formData.append('group_image', file);
            
            fetch('server.php', {
                method: 'POST',
                body: formData,
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('group-info-image').src = data.image_url;
                    document.getElementById('chat-avatar').src = data.image_url;
                    
                  
                    const chatItem = document.querySelector(`.chat-item[data-chat-id="${currentChat.id}"][data-chat-type="group"] .avatar`);
                    if (chatItem) {
                        chatItem.src = data.image_url;
                    }
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });
        
        
        const profileMenuItem = document.getElementById('profile-menu-item');
        const profileModal = document.getElementById('profile-modal');
        
        profileMenuItem.addEventListener('click', function() {
            openModal(profileModal);
            
            
            document.getElementById('profile-fullname').value = currentUser.fullname;
            document.getElementById('profile-username').value = currentUser.username;
            document.getElementById('profile-bio').value = currentUser.bio || '';
            
            if (currentUser.profile_image) {
                document.getElementById('profile-preview').src = currentUser.profile_image;
            }
            
            closeMenu();
        });
        
        
        const profileUpload = document.getElementById('profile-upload');
        
        profileUpload.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (!file) return;
            
           
            const reader = new FileReader();
            reader.onload = function(event) {
                document.getElementById('profile-preview').src = event.target.result;
            };
            reader.readAsDataURL(file);
        });
        
        
        const profileForm = document.getElementById('profile-form');
        
        profileForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const fullname = document.getElementById('profile-fullname').value;
            const username = document.getElementById('profile-username').value;
            const bio = document.getElementById('profile-bio').value;
            const profileImage = document.getElementById('profile-upload').files[0];
            
            const formData = new FormData();
            formData.append('action', 'update_profile');
            formData.append('user_id', currentUser.id);
            formData.append('fullname', fullname);
            formData.append('username', username);
            formData.append('bio', bio);
            
            if (profileImage) {
                formData.append('profile_image', profileImage);
            }
            
            fetch('server.php', {
                method: 'POST',
                body: formData,
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                  
                    currentUser = data.user;
                    localStorage.setItem('user', JSON.stringify(currentUser));
                    
                    
                    document.getElementById('current-user-name').textContent = currentUser.fullname;
                    document.getElementById('current-user-avatar').src = currentUser.profile_image;
                    
                    alert('Profil muvaffaqiyatli yangilandi!');
                    closeModal(profileModal);
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });
        
     
        const logoutMenuItem = document.getElementById('logout-menu-item');
        
        logoutMenuItem.addEventListener('click', function() {
            if (confirm('Haqiqatan ham chiqmoqchimisiz?')) {
                localStorage.removeItem('user');
                window.location.href = 'index.html';
            }
            closeMenu();
        });
        
       
        const menuBtn = document.getElementById('menu-btn');
        const sidebarMenu = document.getElementById('sidebar-menu');
        
        menuBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            
            if (sidebarMenu.style.display === 'block') {
                closeMenu();
            } else {
                openMenu();
            }
        });
        
        
        function openMenu() {
            sidebarMenu.style.display = 'block';
            
           
            const rect = menuBtn.getBoundingClientRect();
            sidebarMenu.style.top = (rect.bottom + 5) + 'px';
            sidebarMenu.style.right = (window.innerWidth - rect.right) + 'px';
            
           
            document.addEventListener('click', closeMenuOnOutsideClick);
        }
        
       
        function closeMenu() {
            sidebarMenu.style.display = 'none';
            document.removeEventListener('click', closeMenuOnOutsideClick);
        }
        
        
        function closeMenuOnOutsideClick(e) {
            if (!sidebarMenu.contains(e.target) && e.target !== menuBtn) {
                closeMenu();
            }
        }
        
        
        function openModal(modal) {
            modal.style.display = 'flex';
            
            
            const closeBtn = modal.querySelector('.close-modal');
            closeBtn.addEventListener('click', function() {
                closeModal(modal);
            });
            
           
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    closeModal(modal);
                }
            });
        }
        
       
        function closeModal(modal) {
            modal.style.display = 'none';
        }
        
        
        loadChats();
        loadContacts();
    }
});