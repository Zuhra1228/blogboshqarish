<?php

$host = 'localhost';
$dbname = 'telechat';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die(json_encode(['success' => false, 'message' => 'Ma\'lumotlar bazasiga ulanishda xatolik: ' . $e->getMessage()]));
}


$request_body = file_get_contents('php://input');
$data = json_decode($request_body, true);


if (!$data && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = $_POST;
}

$action = isset($data['action']) ? $data['action'] : '';

switch ($action) {
    case 'register':
        register($pdo);
        break;
    case 'login':
        login($pdo, $data);
        break;
    case 'get_chats':
        getChats($pdo, $data);
        break;
    case 'get_contacts':
        getContacts($pdo, $data);
        break;
    case 'get_messages':
        getMessages($pdo, $data);
        break;
    case 'send_message':
        sendMessage($pdo, $data);
        break;
    case 'add_contact':
        addContact($pdo, $data);
        break;
    case 'create_group':
        createGroup($pdo);
        break;
    case 'get_group_info':
        getGroupInfo($pdo, $data);
        break;
    case 'get_non_members':
        getNonMembers($pdo, $data);
        break;
    case 'add_members':
        addMembers($pdo, $data);
        break;
    case 'leave_group':
        leaveGroup($pdo, $data);
        break;
    case 'update_group_image':
        updateGroupImage($pdo);
        break;
    case 'update_profile':
        updateProfile($pdo);
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Noto\'g\'ri so\'rov']);
}


function register($pdo) {
    $fullname = $_POST['fullname'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => false, 'message' => 'Bu foydalanuvchi nomi allaqachon mavjud']);
        return;
    }
    
   
    $profile_image_url = null;
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/profile/';
        
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_name = uniqid() . '_' . $_FILES['profile_image']['name'];
        $upload_path = $upload_dir . $file_name;
        
        if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $upload_path)) {
            $profile_image_url = $upload_path;
        }
    }
    
   
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    $stmt = $pdo->prepare("INSERT INTO users (fullname, username, password, profile_image) VALUES (?, ?, ?, ?)");
    $result = $stmt->execute([$fullname, $username, $hashed_password, $profile_image_url]);
    
    if ($result) {
        echo json_encode(['success' => true, 'message' => 'Ro\'yxatdan muvaffaqiyatli o\'tdingiz']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Ro\'yxatdan o\'tishda xatolik yuz berdi']);
    }
}


function login($pdo, $data) {
    $username = $data['username'];
    $password = $data['password'];
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    
    if ($stmt->rowCount() === 0) {
        echo json_encode(['success' => false, 'message' => 'Foydalanuvchi nomi yoki parol noto\'g\'ri']);
        return;
    }
    
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (password_verify($password, $user['password'])) {
      
        unset($user['password']);
        echo json_encode(['success' => true, 'user' => $user]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Foydalanuvchi nomi yoki parol noto\'g\'ri']);
    }
}


function getChats($pdo, $data) {
    $user_id = $data['user_id'];
    
    $personal_chats = [];
    
    $stmt = $pdo->prepare("
        SELECT c.id, u.id as user_id, u.fullname as name, u.profile_image, c.created_at
        FROM contacts c
        JOIN users u ON (c.user_id = ? AND c.contact_id = u.id) OR (c.contact_id = ? AND c.user_id = u.id)
        WHERE c.user_id = ? OR c.contact_id = ?
    ");
    $stmt->execute([$user_id, $user_id, $user_id, $user_id]);
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
       
        $chat_id = $row['id'];
        $last_message = getLastMessage($pdo, $chat_id, 'personal');
        
        $personal_chats[] = [
            'id' => $chat_id,
            'name' => $row['name'],
            'profile_image' => $row['profile_image'],
            'last_message' => $last_message
        ];
    }
    
   
    $group_chats = [];
    
    $stmt = $pdo->prepare("
        SELECT g.id, g.name, g.profile_image, g.created_at
        FROM group_members gm
        JOIN groups g ON gm.group_id = g.id
        WHERE gm.user_id = ?
    ");
    $stmt->execute([$user_id]);
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
       
        $group_id = $row['id'];
        $last_message = getLastMessage($pdo, $group_id, 'group');
        
        $group_chats[] = [
            'id' => $group_id,
            'name' => $row['name'],
            'profile_image' => $row['profile_image'],
            'last_message' => $last_message
        ];
    }
    
    echo json_encode([
        'success' => true,
        'personal_chats' => $personal_chats,
        'group_chats' => $group_chats
    ]);
}


function getLastMessage($pdo, $chat_id, $chat_type) {
    $table = ($chat_type === 'personal') ? 'personal_messages' : 'group_messages';
    $id_field = ($chat_type === 'personal') ? 'contact_id' : 'group_id';
    
    $stmt = $pdo->prepare("
        SELECT * FROM $table
        WHERE $id_field = ?
        ORDER BY timestamp DESC
        LIMIT 1
    ");
    $stmt->execute([$chat_id]);
    
    if ($stmt->rowCount() > 0) {
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    return null;
}


function getContacts($pdo, $data) {
    $user_id = $data['user_id'];
    
    $stmt = $pdo->prepare("
        SELECT u.id, u.fullname, u.username, u.profile_image
        FROM contacts c
        JOIN users u ON (c.user_id = ? AND c.contact_id = u.id) OR (c.contact_id = ? AND c.user_id = u.id)
        WHERE c.user_id = ? OR c.contact_id = ?
    ");
    $stmt->execute([$user_id, $user_id, $user_id, $user_id]);
    
    $contacts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['success' => true, 'contacts' => $contacts]);
}


function getMessages($pdo, $data) {
    $chat_id = $data['chat_id'];
    $chat_type = $data['chat_type'];
    
    $table = ($chat_type === 'personal') ? 'personal_messages' : 'group_messages';
    $id_field = ($chat_type === 'personal') ? 'contact_id' : 'group_id';
    
    $stmt = $pdo->prepare("
        SELECT * FROM $table
        WHERE $id_field = ?
        ORDER BY timestamp ASC
    ");
    $stmt->execute([$chat_id]);
    
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['success' => true, 'messages' => $messages]);
}


function sendMessage($pdo, $data) {
    $chat_id = $data['chat_id'];
    $chat_type = $data['chat_type'];
    $message_type = $data['message_type'];
    $content = $data['content'];
    $sender_id = $data['sender_id'];
    
    $table = ($chat_type === 'personal') ? 'personal_messages' : 'group_messages';
    $id_field = ($chat_type === 'personal') ? 'contact_id' : 'group_id';
    
    $stmt = $pdo->prepare("
        INSERT INTO $table ($id_field, sender_id, message_type, content)
        VALUES (?, ?, ?, ?)
    ");
    $result = $stmt->execute([$chat_id, $sender_id, $message_type, $content]);
    
    if ($result) {
        $message_id = $pdo->lastInsertId();
        
        
        $stmt = $pdo->prepare("SELECT * FROM $table WHERE id = ?");
        $stmt->execute([$message_id]);
        $message = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo json_encode(['success' => true, 'message' => $message]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Xabar yuborishda xatolik yuz berdi']);
    }
}


function addContact($pdo, $data) {
    $user_id = $data['user_id'];
    $contact_username = $data['contact_username'];
    
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$contact_username]);
    
    if ($stmt->rowCount() === 0) {
        echo json_encode(['success' => false, 'message' => 'Bunday foydalanuvchi mavjud emas']);
        return;
    }
    
    $contact = $stmt->fetch(PDO::FETCH_ASSOC);
    $contact_id = $contact['id'];
    
 
    if ($user_id == $contact_id) {
        echo json_encode(['success' => false, 'message' => 'O\'zingizni kontakt qilib qo\'sha olmaysiz']);
        return;
    }
    
 
    $stmt = $pdo->prepare("
        SELECT id FROM contacts
        WHERE (user_id = ? AND contact_id = ?) OR (user_id = ? AND contact_id = ?)
    ");
    $stmt->execute([$user_id, $contact_id, $contact_id, $user_id]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => false, 'message' => 'Bu foydalanuvchi allaqachon kontaktlaringizda mavjud']);
        return;
    }
    
    
    $stmt = $pdo->prepare("INSERT INTO contacts (user_id, contact_id) VALUES (?, ?)");
    $result = $stmt->execute([$user_id, $contact_id]);
    
    if ($result) {
        echo json_encode(['success' => true, 'message' => 'Kontakt muvaffaqiyatli qo\'shildi']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Kontakt qo\'shishda xatolik yuz berdi']);
    }
}


function createGroup($pdo) {
    $creator_id = $_POST['creator_id'];
    $group_name = $_POST['group_name'];
    $members = json_decode($_POST['members'], true);
    
   
    $profile_image_url = null;
    if (isset($_FILES['group_image']) && $_FILES['group_image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/group/';
        
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_name = uniqid() . '_' . $_FILES['group_image']['name'];
        $upload_path = $upload_dir . $file_name;
        
        if (move_uploaded_file($_FILES['group_image']['tmp_name'], $upload_path)) {
            $profile_image_url = $upload_path;
        }
    }
    
 
    $stmt = $pdo->prepare("INSERT INTO groups (name, creator_id, profile_image) VALUES (?, ?, ?)");
    $result = $stmt->execute([$group_name, $creator_id, $profile_image_url]);
    
    if (!$result) {
        echo json_encode(['success' => false, 'message' => 'Guruh yaratishda xatolik yuz berdi']);
        return;
    }
    
    $group_id = $pdo->lastInsertId();
    
   
    $stmt = $pdo->prepare("INSERT INTO group_members (group_id, user_id) VALUES (?, ?)");
    $stmt->execute([$group_id, $creator_id]);
    
  
    foreach ($members as $member_id) {
        $stmt->execute([$group_id, $member_id]);
    }
    
    echo json_encode(['success' => true, 'message' => 'Guruh muvaffaqiyatli yaratildi']);
}


function getGroupInfo($pdo, $data) {
    $group_id = $data['group_id'];
    
    
    $stmt = $pdo->prepare("SELECT * FROM groups WHERE id = ?");
    $stmt->execute([$group_id]);
    
    if ($stmt->rowCount() === 0) {
        echo json_encode(['success' => false, 'message' => 'Guruh topilmadi']);
        return;
    }
    
    $group = $stmt->fetch(PDO::FETCH_ASSOC);
    
   
    $stmt = $pdo->prepare("
        SELECT u.id, u.fullname, u.username, u.profile_image
        FROM group_members gm
        JOIN users u ON gm.user_id = u.id
        WHERE gm.group_id = ?
    ");
    $stmt->execute([$group_id]);
    
    $members = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'group' => $group,
        'members' => $members
    ]);
}


function getNonMembers($pdo, $data) {
    $user_id = $data['user_id'];
    $group_id = $data['group_id'];
    
    
    $stmt = $pdo->prepare("
        SELECT u.id, u.fullname, u.username, u.profile_image
        FROM contacts c
        JOIN users u ON (c.user_id = ? AND c.contact_id = u.id) OR (c.contact_id = ? AND c.user_id = u.id)
        WHERE (c.user_id = ? OR c.contact_id = ?)
        AND u.id NOT IN (
            SELECT user_id FROM group_members WHERE group_id = ?
        )
        AND u.id != ?
    ");
    $stmt->execute([$user_id, $user_id, $user_id, $user_id, $group_id, $user_id]);
    
    $contacts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['success' => true, 'contacts' => $contacts]);
}


function addMembers($pdo, $data) {
    $group_id = $data['group_id'];
    $member_ids = $data['member_ids'];
    

    $stmt = $pdo->prepare("INSERT INTO group_members (group_id, user_id) VALUES (?, ?)");
    
    foreach ($member_ids as $member_id) {
        $stmt->execute([$group_id, $member_id]);
    }
    
    echo json_encode(['success' => true, 'message' => 'A\'zolar muvaffaqiyatli qo\'shildi']);
}


function leaveGroup($pdo, $data) {
    $user_id = $data['user_id'];
    $group_id = $data['group_id'];
    
  
    $stmt = $pdo->prepare("DELETE FROM group_members WHERE group_id = ? AND user_id = ?");
    $result = $stmt->execute([$group_id, $user_id]);
    
    if ($result) {
        echo json_encode(['success' => true, 'message' => 'Guruhdan muvaffaqiyatli chiqdingiz']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Guruhdan chiqishda xatolik yuz berdi']);
    }
}


function updateGroupImage($pdo) {
    $group_id = $_POST['group_id'];
    
    
    $profile_image_url = null;
    if (isset($_FILES['group_image']) && $_FILES['group_image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/group/';
        
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_name = uniqid() . '_' . $_FILES['group_image']['name'];
        $upload_path = $upload_dir . $file_name;
        
        if (move_uploaded_file($_FILES['group_image']['tmp_name'], $upload_path)) {
            $profile_image_url = $upload_path;
        }
    }
    
    if (!$profile_image_url) {
        echo json_encode(['success' => false, 'message' => 'Rasm yuklashda xatolik yuz berdi']);
        return;
    }
    
  
    $stmt = $pdo->prepare("UPDATE groups SET profile_image = ? WHERE id = ?");
    $result = $stmt->execute([$profile_image_url, $group_id]);
    
    if ($result) {
        echo json_encode(['success' => true, 'image_url' => $profile_image_url]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Guruh rasmini yangilashda xatolik yuz berdi']);
    }
}


function updateProfile($pdo) {
    $user_id = $_POST['user_id'];
    $fullname = $_POST['fullname'];
    $username = $_POST['username'];
    $bio = $_POST['bio'];
    
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
    $stmt->execute([$username, $user_id]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => false, 'message' => 'Bu foydalanuvchi nomi allaqachon mavjud']);
        return;
    }
    
    $profile_image_url = null;
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/profile/';
        
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_name = uniqid() . '_' . $_FILES['profile_image']['name'];
        $upload_path = $upload_dir . $file_name;
        
        if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $upload_path)) {
            $profile_image_url = $upload_path;
            
            $stmt = $pdo->prepare("UPDATE users SET profile_image = ? WHERE id = ?");
            $stmt->execute([$profile_image_url, $user_id]);
        }
    }
    
    $stmt = $pdo->prepare("UPDATE users SET fullname = ?, username = ?, bio = ? WHERE id = ?");
    $result = $stmt->execute([$fullname, $username, $bio, $user_id]);
    
    if ($result) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
       
        unset($user['password']);
        
        echo json_encode(['success' => true, 'user' => $user]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Profilni yangilashda xatolik yuz berdi']);
    }
}
?>